#include <iostream>
using namespace std;
int maxl(int a,int b) {
	return (a > b ? a : b);}
int maxl(int a, int b, int c) {
	return (a > b ? a : b) < c ? c : (a > b ? a : b);}
double maxl(double a, double b) {
	return (a > b ? a : b);}
double maxl(double a, double b, double c) {
	return  (a > b ? a : b) < c ? c : (a > b ? a : b);}

void lab1_2test() {
	int a, b, c;float d, e, f;
	cout << "two int\n";
	cin >> a >> b;

	cout << "��int,max:" << maxl(a, b) << endl;

	cout << "three int\n";
	cin >> a >> b >> c;
	cout << "three int max:" << maxl(a, b, c) << endl;
	cout << "two double\n";
	cin >> d >> e;
	cout << "max:" << maxl(d, e) << endl;
	cout << "three double\n";
	cin >> d >> e >> f;
	cout << "max:" << maxl(d, e, f);}