#include "��ȫ�������ͷ�ļ�.h"
#include <iostream>
using namespace std;
int main()
{
	//addtest();
	//lab1_1test();
	//lab1_2test();
	//lab1_3test();
	//lab1_4test();
	//fibtest();
/*	int a = INT32_MAX;
	
		a = a + 1;
		a = a + 1;
	
	//�ڻ���ǰ����֤
	*/
	//strcpytest();
	//strcattest();
	//test();

	vehicle a;
	bicycle b;
	motorcar c;
	motorcycle d;
	a.Run();
	a.Stop();
	b.Run();
	b.Stop();
	c.Run();
	c.Stop();
	d.Run();
	d.Stop();
	
	cout << "ָ��"<<endl;
	vehicle* xa;

	xa = &a;
	xa->Run();
	xa->Stop();

	xa = &b;
	xa->Run();
	xa->Stop();

	xa = &c;
	xa->Run();
	xa->Stop();


}