#pragma once
#include <iostream>
using namespace std;
int add(int a, int b);
void addtest();

float Convert(float TempFer);
void lab1_1test();

int maxl(int a, int b);
int maxl(int a, int b, int c);
double maxl(double a, double b);
double maxl(double a, double b, double c);
void lab1_2test();

template <typename O>O maxl(O a, O b);
template <typename O>O maxl(O a, O b, O c);
void lab1_3test();

void lab1_4test();

int fib(int n);
void fibtest();

void strcpytest();
void test();
void strcattest();
class vehicle
{
public:
	vehicle();
	virtual void Run() {
		cout << "Vehicle is running." << endl;
	}
	virtual void Stop() {
		cout << "Vehicle is stop." << endl;
	}
};

class bicycle :public vehicle {
public:
	bicycle();
	void Run() {
		cout << "Bicycle is running." << endl;
	}
	void Stop() {
		cout << "Bicycle is stop." << endl;
	}
};

class motorcar :public vehicle {
public:
	motorcar();
	void Run() {
		cout << "Motorcar is running." << endl;
	}
	void Stop() {
		cout << "Motorcar is stop." << endl;
	}
};

class motorcycle :public bicycle,public motorcar {
public:
	motorcycle();
	void Run() {
		cout << "Motorcycle is running." << endl;
	}
	void Stop() {
		cout << "Motorcycle is stop." << endl;
	}
};
