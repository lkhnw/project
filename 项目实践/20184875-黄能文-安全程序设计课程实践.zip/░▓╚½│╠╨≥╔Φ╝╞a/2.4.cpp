#include "��ȫ�������ͷ�ļ�.h"
#include <iostream>
using namespace std;
vehicle::vehicle() {
	cout << "This is a vehicle." << endl;
}
bicycle::bicycle() {
	cout << "This is a bicycle." << endl;
}
motorcar::motorcar() {
	cout << "This is a motorcar." << endl;
}
motorcycle::motorcycle() {
	cout << "This is a motorcycle." << endl;
}