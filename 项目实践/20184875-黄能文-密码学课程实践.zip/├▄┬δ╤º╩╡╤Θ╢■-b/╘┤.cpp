#include<iostream>
#include<string.h>
using namespace std;
int main()
{
	int i, j, l, k, m, num[30];
	char key[30], plantext[100], plantext2[100], cipher[100];
	cout << "������ؼ���\n";
	cin >> key;
	l = strlen(key);
	for (i = 0; i < l; i++)
	{
		num[i] = 0;
		for (j = 0; j < l; j++)
		{

			if (key[j] <= key[i])
			{

				num[i] = num[i] + 1;
			}
			if (key[j] == key[i] && j > i)
				num[i] = num[i] - 1;

		}
	}
	cout<<"����������\n";
	cin>>plantext;
	k = strlen(plantext);

	i = 0;											//ĩβ��x
	for (m = k % l; m < l; m++)
	{

		plantext[k + i] = 'x';
		i++;
	}

	if (k % l == 0)										//�����ж�����
		m = k / l;
	else
		m = k / l + 1;
	cout<<"����:\n";
	for (i = 0; i < m; i++)
	{
		for (j = 0; j < l; j++)
		{

			cipher[i * l + j] = plantext[i * l + num[j] - 1];

		}
	}
	for (i = 0; i < l; i++)								//�������
	{
		for (j = 0; j < m; j++)
			cout<< cipher[j * l + i];
	}
	cout<<"\n";

	cout<<"����:\n";								//��������
	for (i = 0; i < m; i++)
	{
		for (j = 0; j < l; j++)
		{

			plantext2[i * l + num[j] - 1] = cipher[i * l + j];
		}
	}
	plantext2[(i - 1) * l + j] = '\0';
	cout<< plantext2;
	return 0;
}