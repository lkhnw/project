#include <stdio.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <unistd.h>
#include <cstring>
#include <stdlib.h>
#include <dirent.h>
#define buflen 100

int make_server_socket(int portnum,int maxconnect);
void process_rq( char* , int);
char* content_type(const char*);
void send_data(int sockfd,char* ct,char* filename);
void send_404(int sockfd);
bool isadir(const char * arg);
void do_ls(const char* arg,int sockfd);
void do_out(const char* arg,int sockfd);
bool end_in_out(char* arg);
void do_out(const char* arg,int sockfd);
int main(){
  int sock,newsock;
  char buf[buflen];
  struct sockaddr_in addr,newaddr;
  addr.sin_family = AF_INET;
  addr.sin_port = htons(8080);
  addr.sin_addr.s_addr = htonl(INADDR_ANY);

  if((sock = socket(AF_INET,SOCK_STREAM,0))<0){
  	printf("socket error\n");
	exit(-1);
  }
  printf("socket success\n");
  int b = bind(sock,(struct sockaddr*)&addr,sizeof(addr));
  if(b<0){printf("bind error\n"); exit(-1);}
  printf("bind success\n");
  int l = listen(sock,1);
  if(l<0){
	  printf("listen error\n"); 
  	exit(-1);
  }
  printf("listen success\n");
  while(1){
	socklen_t sin_size =sizeof(struct sockaddr_in);
  	if((newsock = accept(sock,(struct sockaddr *)&newaddr,&sin_size))<0){
	printf("accept error\n");
	continue;
	}	
	printf("receive a accept\n");
		
		int recvbytes;
		recvbytes = recv(newsock,buf,buflen,0);
		buf[recvbytes] = '\0';
		if(recvbytes>0){
			shutdown(newsock,SHUT_RD);
			printf("recv:%s",buf);
			printf("\n");
		//	printf("!!!");
			process_rq(buf,newsock);
			printf("ok\n");
	//		close(newsock);   receive a close request from client and then close the sock.should write in send_data? or process_rq?
        }
    }
}
int make_server_socket(int portnum,int maxconnect){
	struct sockaddr_in addr;
	addr.sin_family = AF_INET;
	addr.sin_port = htons(portnum);
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	//zero
	int sock;
	if((sock = socket(AF_INET,SOCK_STREAM,0))<0){
		printf("socket error");
		return -1;
	}else{printf("socket success\n");}
	int b = bind(sock,(struct sockaddr*)&addr,sizeof(addr));
	if(b<0){printf("bind error"); close(sock);}
	printf("bind success\n");
	int l = listen(sock,maxconnect);
	if(l<0){printf("listen error\n");}
	printf("listen success\n");
	return sock;
}
void process_rq( char* requestbuf,int clfd){
	printf("process_rq\n");
	char req_line[100];
	char method[10];
   	char ct[15];
   	char arg[30];
	strcpy(req_line,strtok(requestbuf,"\n"));
	strcpy(method,strtok(req_line," /"));
	strcpy(arg,strtok(NULL," /"));
	strcpy(ct,content_type(arg));
	if (strcmp(method, "GET") != 0)  //是否为GET请求
    {
        //send_error(clnt_write);
	printf("no get\n");
        return ;
    	}
	char filename[30];
	char arg1[30],arg2[30];
	strcpy(filename,arg);
	strcpy(arg1,arg);
	strcpy(arg2,arg);
	if(isadir(arg1)){
		// dir
	 do_ls(filename,clfd);
	}
	else if(end_in_out(arg2)){
		// .out
		do_out(filename,clfd);
	}
	else{
        send_data(clfd, ct, filename); //响应给客服端
	}
        return ;
}

char * content_type(const char *file)
{
    //
    char extension[20];
    char file_name[20];
    strcpy(file_name, file);
    strtok(file_name, ".");
    char * ex = strtok(NULL,".");
    if (ex != NULL){
	    strcpy(extension,ex);
 //   strcpy(extension, strtok(NULL, "."));
    }
//	printf("error3\n");
    if (!strcmp(extension, "html") || !strcmp(extension, "htm"))
        return "text/html";  //html格式的文本数据
    else
        return "text/plain";
}

void send_data(int sockfd,char* ct,char* filename){
    printf("send data");
    printf("%s\n",filename);
    char protocol[] = "HTTP/1.1 200 OK\r\n";  //状态行(用HTTP1.1版本进行响应，你的请求已经正确处理)
    char server[] = "Server: Linux Web Server \r\n"; //服务端名
    char cnt_type[100];
    char cnt_len[100];
    char buf[100];
    FILE *send_file;

    sprintf(cnt_type, "Content-type: %s\r\n\r\n", ct);
    send_file = fopen(filename, "r"); //读本地配置文件
//    fseek(send_file,0,SEEK_END);//定位到文件的最后面
//    long length  = ftell(send_file);   
//    fseek(send_file,0,SEEK_SET);
     if (send_file == NULL)
    {
       send_404(sockfd);
       printf("%s",filename);
       printf(" no file,so send 404\n");
        return;
    }
     fseek(send_file,0,SEEK_END);
     long length = ftell(send_file);
     fseek(send_file,0,SEEK_SET);
    send(sockfd,protocol,strlen(protocol),0);
    send(sockfd,server,strlen(server),0);
    sprintf(cnt_len,"Content-Length: %d\r\n", length); 
    send(sockfd, cnt_len, strlen(cnt_len),0);   
    send(sockfd,cnt_type,strlen(cnt_type),0);
 //   printf("%s%s%s%s",protocol,server,buf,cnt_type);
     /*传输请求数据*/
    while (fgets(buf, 100, send_file) != NULL)
    {
        send(sockfd,buf,strlen(buf),0);
//	printf("%s",buf);        
    }
    send(sockfd,"\r\n",2,0);
    fclose(send_file);
     //服务端响应客服端请求后立即断开连接（短链接）
}

void send_404(int sockfd){
	char buf[100];
	sprintf(buf,"HTTP/1.1 404 Not Found\r\n");
	send(sockfd,buf,strlen(buf),0);
	sprintf(buf,"Server:Linux Web Server\r\n");
	send(sockfd,buf,strlen(buf),0);
	sprintf(buf,"Content-type: text/html\r\n");
	FILE * file404 = fopen("404.html","r");
	fseek(file404,0,SEEK_END);
	long len = ftell(file404);
	fseek(file404,0,SEEK_SET);
	sprintf(buf,"Content-length:%d\r\n\r\n",len);
	send(sockfd,buf,strlen(buf),0);
	while(fgets(buf,100,file404) !=NULL ){
		send(sockfd,buf,strlen(buf),0);
	}
	fclose(file404);
}
bool isadir(const char * arg){
	DIR * pdir = opendir(arg);
	if(pdir==NULL){
	 return false;
	}
	printf("dir :%s\n",arg);
	return true;
}
void do_ls(const char* arg,int sockfd){
	DIR * pdir = opendir(arg);
        struct dirent *entry;	
	char buf[100];
	int i=1;
	while(entry=readdir(pdir))
        {
        printf("FileName%d=%s\r\n",i,entry->d_name);
	sprintf(buf,"%sfilename%d=%s\n",buf,i,entry->d_name);
        i++;
        }
        closedir(pdir);
	char head[100];
	sprintf(head,"HTTP/1.1 200 OK\r\nServer:Linux Web Server \r\nContent-type: text/html\r\nContent-length:%d\r\n\r\n",strlen(buf)+26);
	send(sockfd,head,strlen(head),0);
	send(sockfd,"<html><body>",12,0);
//	send(sockfd,head,strlen(head),0);
//	send(sockfd,"</body></html>",14,0);
	send(sockfd,buf,strlen(buf),0);
	send(sockfd,"</body></html>",14,0);
	return;
}
bool end_in_out(char* arg){
	strtok(arg,".");
	if(strcmp("out",strtok(NULL," ."))==0){
			return true;
			}
	 return false;
}
void do_out(const char* arg,int sockfd){
	printf("out\n");
	FILE* f = NULL;
	char buf[100];
	char buff[1000];
	char out[30];
	memset(buff,0,sizeof(buff));
	sprintf(out,"./%s",arg);
	f=popen(out,"r");
	while(NULL !=fgets(buf,sizeof(buf),f)){
		sprintf(buff,"%s%s",buff,buf);
	}
	char head[100];
	sprintf(head,"HTTP/1.1 200 OK\r\nSeerver: Linux Web Server \r\nContent-type text/html\r\nContent-length:%d\r\n\r\n",strlen(buff)+26);
	send(sockfd,head,strlen(head),0);
	send(sockfd,"<html><body>",12,0);
	send(sockfd,buff,strlen(buff),0);
	send(sockfd,"</body></html>",14,0);

}
