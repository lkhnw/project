

#### 1.WEB

第一个系统weblogic反序列化，

##### 上传木马

![image-20210628095605932](img\DC2-godzillaupload)

##### 得到flag1

在mssql用户桌面存在flag1文件，得到 ESCCTF{97g9_h1jk_ca5}及下台机器的提示：

![image-20210628095914755](img\DC2-flag1)

本地管理员密码：administrator  1.9admin

#### 2.内网1

10.10.10.50

##### 找到信息泄露的数据库连接文件

![image-20210628100427384](img\DC2-nw1_webconfig)

##### 得到了flag2，同时也是登录密码

flag2:ESCCTF{2a3s_gl9p4d}

![image-20210628100734927](img\DC2-flag2)

##### 

![image-20210628101635281](img\DC2-sql_injection)

##### 通过sql注入漏洞修改本地管理员密码并开3389关闭防火墙

![image-20210628103717282](img\DC2-sql_injection_osshell)

##### 既可以在sqlmap中执行系统命令，也可以在网站目录找到sa用户的密码来连接数据库执行命令

##### 并获取到flag3和下一个机器提示信息

![image-20210628150459635](img\DC2-xpcmdshell)

远程桌面到服务器   反弹shell到msf

![image-20210628160539789](img\DC2-nw1_rdp)

成功读取域管理员密码hash和明文

![image-20210628162905931](img\DC2-DCADMINpass)

#### 3.DC

10.10.10.10

##### 利用psexe进行攻击，成功拿到域控服务器

![image-20210628163407020](img\DC2-psexe)



##### 连接DC桌面，在一个域管理员桌面发现文件"what is this"  

![image-20210628163941165](img\DC2-flag4)

flag4:ESCCTF{JNMCL_JA_AD}