package sample;

import com.sun.javafx.robot.impl.FXRobotHelper;
import sample.Data.BaseData.Constant;
import sample.Data.BaseData.Doctor;
import sample.Data.BaseData.HumanSourceManerger;
import sample.Data.BaseData.User;

import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import sample.Logic.LoginManerger;

public class DeleteUser {
    public TextArea information;
    public TextField input;
    private final String root = "Root";

    private static String getInformation(User user){
        String result = "";
        result += "姓名：" + user.getName() +  "\n";
        result += "登录名(ID)：" + user.getID() + "\n" ;
        result += "所属科室：" + user.getAdmisitrative() + "\n";
        result += "职位：" + Constant.getString(user.getKind()) + "\n";
        if(user instanceof Doctor)
            result += "医生职称：" + Constant.getString(((Doctor)user).getLevel()) + "\n";
        return result;
    }

    public void onFindPushed(){
        try {
            User user = HumanSourceManerger.get().getUser(input.getText());
            if (user == null)
                AlertBox.display("该用户不存在！！！","查找时错误");
            else
                information.setText(getInformation(user));
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"查找时错误");
        }
    }
    public void onDeletePushed(){
        try{
            HumanSourceManerger manerger = HumanSourceManerger.get();
            User user = manerger.getUser(input.getText());
            if(user == null){
                AlertBox.display("该用户不存在！！！","删除时错误");
            }else if(user.getID().equals(LoginManerger.get().getUser().getID())) {
                AlertBox.display("不能自己删除自己！！！","删除时错误");
            } else{
                boolean confirm = ConfirmBox.display("确定要删除用户【" + user.getID()+ "】吗","删除前确认");
                if(confirm){
                    manerger.deleteUser(user.getID());
                    information.clear();
                }
            }
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"删除时错误");
        }
    }
    public void onExitPushed(){
        try{
            SceneChanger.get().loadScene("main");
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"转场时出错");
        }
    }
}
