package sample.Data.BaseData;

import sample.Logic.Tool;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.*;

public class ScheduleManerger extends Saver {
    private static String file = "ScheduleManerger.txt";
    private HashMap<String, HashMap<String,ScheduleRule>> ruleList;//每个医生对应的排班计划规则
    private HashMap<STime, HashSet<String>> arrageedList;
    static ScheduleManerger instance = null;

    private ScheduleManerger(){
        ruleList = new HashMap<>();
        arrageedList = new HashMap<>();
    }

    public static ScheduleManerger get()throws Exception{
        if(instance == null){
            Object readResult = read(file);
            if(readResult == null)
                instance = new ScheduleManerger();
            else
                instance = (ScheduleManerger) readResult;
        }
        return instance;
    }

    public Iterator<ScheduleRule> getRule(Doctor doctor)throws Exception{//得到某个医生的排班计划规则
        try{
            return ruleList.get(doctor.getID()).values().iterator();
        }catch(NullPointerException e){
            throw new Exception("该医生" + doctor.getID() + "不存在");
        }
    }
    public ScheduleRule gerRule(String doctor,String name)throws Exception{
        HashMap<String,ScheduleRule> list =  ruleList.get(doctor);
        if(list == null)
            throw new Exception("该医生没有参加排班");
        ScheduleRule rule = list.get(doctor);
        if(rule == null)
            throw new Exception("该医生不存在此排班规则");
        return rule;
    }


    public void createRule(Doctor doctor,boolean[][] inform,String name)throws Exception{//创建一个规则
        ScheduleRule rule = new ScheduleRule(name,doctor,inform);
        if(ruleList.get(doctor.getID())== null)
            ruleList.put(doctor.getID(),new HashMap<>());
        if(ruleList.get(doctor.getID()).get(name) != null)
            throw new Exception("同一个医生不能有重复名称的排班规则");
        ruleList.get(doctor.getID()).put(name,rule);
        save(file);
    }

    public void deleteRule(String doctor,String name)throws Exception{//删除某个排班计划
        HashMap<String,ScheduleRule> list = ruleList.get(doctor);
        if(list == null)
            throw new Exception("该医生不在排班表上");
        if(list.remove(name) == null)
            throw new Exception("该规则不在排班表上");
        save(file);
    }

    public void createSchedule(LocalDate begin,LocalDate end,String doctor,String _rule)throws Exception{
        if(begin.compareTo(end) > 0)
            throw  new Exception("排班开始时间不得小于结束时间");
        boolean[][] rule = gerRule(doctor,_rule).getInform();
        int weekOfDay = Tool.getWeekDay(begin.getDayOfWeek());
        end = end.plusDays(1);//让最后一天也能被加上
        for(; !end.equals(begin); begin =  begin.plusDays(1),weekOfDay = (weekOfDay + 1) % 7 ){
            if(rule[weekOfDay][0]){
                createAndAddinList(doctor,begin,true);
            }
            if(rule[weekOfDay][1]){
                createAndAddinList(doctor,begin,false);
            }
        }
    }

    private void createAndAddinList(String doctor,LocalDate start,boolean isBefoenoon){
        STime time = new STime(start,isBefoenoon);
        HashSet<String> list = arrageedList.get(time);
        if(list == null){
            list = new HashSet<>();
            arrageedList.put(time,list);
        }
        list.add(doctor);
    }


    public Iterator<String> getAvaiableDoctors(Calendar time)throws Exception{
        try{
            return arrageedList.get(new STime(time)).iterator();
        }catch(NullPointerException e){
            throw new Exception("这个时候没有医生排班");
        }
    }

    public Iterator<STime> getAllTime(){
        return arrageedList.keySet().iterator();
    }




}
