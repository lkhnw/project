package sample.Data.BaseData;

public  class PayData {//抽象类用来表述一个数据是否能结算
    private boolean isPayed;
    private int caseNumber;//对应的病历号
    private int number;//对应发票号
    private float price;
    private String name;//付费项目名称


    public PayData(Case caseData,int number,String name,float price){
        isPayed = false;
        this.caseNumber = caseData.getNumber();
        this.number = number;
        this.name = name;
        this.price = price;
    }

    public int getCaseNumber() {
        return caseNumber;
    }

    public void setCaseNumber(int caseNumber) {
        this.caseNumber = caseNumber;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public float getPrice(){return price;}

    public void pay(){
        isPayed = true;
    }
    public boolean IsPayed(){
        return isPayed;
    }

    public String getName(){
        return name;
    }
}
