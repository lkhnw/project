package sample.Data.BaseData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class PayDataManerger {
    private static int counter = 0;
    private HashMap<Integer, ArrayList<PayData>> datas;//每个病历号对应的发票数据
    private HashMap<Integer,PayData> paydatas;//每个发票编号对应的发票据
    private static PayDataManerger instance = null;

    private PayDataManerger(){
        datas = new HashMap<>();
        paydatas = new HashMap<>();
    }

    public static PayDataManerger get(){
        if(instance == null)
            instance = new PayDataManerger();
        return instance;
    }

    public PayData createData(Case caseData,String name,float price){
        PayData data = new PayData(caseData,++counter,name,price);
        paydatas.put(data.getNumber(),data);
        ArrayList<PayData> list = datas.get(caseData.getNumber());
        if(list == null){
            list = new ArrayList<>();
            datas.put(caseData.getNumber(),list);
        }
        list.add(data);
        return data;
    }

    public Iterator<PayData> getData(int data)throws Exception{//根据病例号得到发票数据
        try{
            return datas.get(data).iterator();
        }catch(NullPointerException e){
            throw new Exception("病例号不存在");
        }
    }

    public Iterator<PayData> getData(){
        return paydatas.values().iterator();
    }

    public void deleteData(PayData data){
        paydatas.remove(data.getNumber());
        datas.get(data.getCaseNumber()).remove(data);
    }
}
