package sample.Data.BaseData;

import java.io.Serializable;

public class IRecord implements Serializable {
    private String code;
    private String name;
    private String ICD;
    private String menu;
    public IRecord(String code,String name,String ICD,MenuClass Iclass){
        this.code = code;
        this.name = name;
        this.ICD = ICD;
        if(Iclass != null) this.menu = Iclass.getName();
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getICD() {
        return ICD;
    }

    public void setICD(String ICD) {
        this.ICD = ICD;
    }

    public String getIclassName() {
        return menu;
    }

    public void setIclass(MenuClass iclass) {
        if(iclass != null) menu = iclass.getName();
    }
}
