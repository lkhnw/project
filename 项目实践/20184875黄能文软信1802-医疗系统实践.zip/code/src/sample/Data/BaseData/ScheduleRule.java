package sample.Data.BaseData;

import java.io.Serializable;

public class ScheduleRule implements Serializable {//排班规则
    private String name;//所用的名字
    private String doctor;//所对的医生ID
    private String doctorName;//所对的医生名字
    private boolean[][] inform;//具体的排班消息
    private String informToString;//具体排班信息的对应字符串

    private static String setInformToString(boolean[][] inform)throws Exception{
        try {
            String result = "";
            for (int i = 0; i != 7; i++) {
                for (int x = 0; x != 2; x++)
                    result += inform[i][x] ? "1" : "0";
            }
            return result;
        }catch(Exception e){
            throw new Exception("在生成排班规则时，数组提交格式" +inform.length+ "," + inform[0].length + "错误。正确应为6,2");
        }
    }

    public ScheduleRule(String name,Doctor doctor,boolean[][] inform)throws Exception{
        this.name = name;
        this.inform = inform;
        this.doctor = doctor.getID();
        this.doctorName = doctor.getName();
        this.informToString = setInformToString(inform);
    }

    public String getName() {
        return name;
    }

    public String getDoctor() {
        return doctor;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public boolean[][] getInform() {
        return inform;
    }

    public void setInform(boolean[][] inform)throws Exception{
        informToString = setInformToString(inform);
        this.inform = inform;
    }

    public String getInformToString() {
        return informToString;
    }
}
