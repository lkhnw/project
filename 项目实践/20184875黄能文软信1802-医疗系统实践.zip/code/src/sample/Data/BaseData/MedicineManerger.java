package sample.Data.BaseData;

import sample.AlertBox;

import java.util.HashMap;
import java.util.Iterator;

public class MedicineManerger extends Saver{
        private static MedicineManerger instance = null;
        private static String file = "medicine.txt";

        private HashMap<String,Medicine> list = new HashMap<>();

        public static MedicineManerger get(){
            try {
                if (instance == null) {
                    Object result = read(file);
                    if (result != null)
                        instance =  (MedicineManerger) result;
                    else {
                        instance = new MedicineManerger();
                        instance.save(file);
                    }
                }
            }catch(Exception e){
                AlertBox.display(e.getMessage(),"读写文件时的错误");
            }
            return instance;
        }

        public void createMedicine(String name,String unit,float price,String code)throws Exception{
            if(list.get(name) != null)
                throw new Exception("不能在目录中添加名字相同的药品");
            list.put(name,new Medicine(name,unit,price,code));
            save(file);
        }

        public Medicine findMedicine(String name){
            return list.get(name);
        }

    public Iterator<Medicine> getMedicineList(){
        return list.values().iterator();
    }

    public void deleteMedicine(String name)throws Exception{
        if(list.get(name) == null)
            throw new Exception(name + "不存在");
        list.remove(name);
        save(file);
    }

}
