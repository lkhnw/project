package sample.Data.BaseData;

import java.util.HashMap;
import java.util.Iterator;

public class MenuManerger extends  Saver {//可以保存到文件里
    private static String file = "Menu.txt";

    private HashMap<String,MenuClass> list;

    private static MenuManerger instance  = null;

    private MenuManerger(){
        list = new HashMap<>();
    }

    public static MenuManerger get()throws  Exception{
            if (instance != null) return instance;
            else {
                Object result = read(file);
                if(result == null){
                    instance = new MenuManerger();
                    instance.save(file);
                    return instance;
                }
                instance = (MenuManerger) result;
                return instance;
            }
    }

    //得到所有目录的列表
    public Iterator<MenuClass> getAllClass(){
        return list.values().iterator();
    }

    public IRecord getILL(String name){//得到一个疾病数据
        Iterator<MenuClass> iter = list.values().iterator();
        while(iter.hasNext()){
            IRecord result = iter.next().getRecord(name);
            if(result != null) return result;
        }
        return null;
    }


    //添加一个新目录，名字不能有重复的
    public void add(String code,String name)throws Exception{
        if(list.get(name) != null) throw new Exception("疾病目录的名称不能重复");
        list.put(name , new MenuClass(name,code));
        save(file);
    }

    //根据名字删除
    public void delete(String name)throws Exception{
        if(list.get(name) == null)
            throw new Exception("该疾病目录不存在");
        list.remove(name);
        save(file);
    }

    //根据名字得到名单
    public MenuClass getMenu(String name){ return list.get(name); }

    public void save()throws Exception{
        save(file);
    }

}
