package sample.Data.BaseData;

import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils;

import java.io.*;

public class Saver implements  Serializable{
    boolean flag = false;
    //从指定文件读取数据
    protected static Object read(String fileName)throws Exception{
        try {
            File file = new File(fileName);
            System.out.println(file);
            if (!file.exists()){
                file.createNewFile();
                return null;
            }
            System.out.println(file.exists());
            ObjectInputStream in = new ObjectInputStream(new FileInputStream(file));
            return in.readObject();
        }catch(FileNotFoundException e){
            throw new Exception("文件无效，数据丢失");

        }catch(Exception e){
            throw new Exception("文件读写时出现错误！！！");
        }
    }
    //向指定文件写入数据
    protected void save(String fileName)throws Exception{
        try{
            File file = new File(fileName);
            flag = false;
            if(!file.exists()) file.createNewFile();
            new Thread(()-> {
                try{
                    new ObjectOutputStream(new FileOutputStream(file)).writeObject(this);
                } catch(Exception e){
                    flag = true;
                }
            }).start();
            if(flag) throw new Exception("数据保存时出现异常！！！");

        }catch(FileNotFoundException e){
            throw new Exception("文件无效，数据丢失");
        }catch(Exception e){
            throw new Exception("数据未能成功保存");
        }
    }

    //删除数据
    public void clear(String fileName){
        File file = new File(fileName);
        if(file.exists()) file.delete();
    }

}
