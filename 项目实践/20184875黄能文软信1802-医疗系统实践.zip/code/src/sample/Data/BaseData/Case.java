package sample.Data.BaseData;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;

public class Case implements Serializable {
    private int number;//病历号
    private String name;//姓名
    private enum Gender{MALE,FEMALE}
    private Gender gender;//性别
    private LocalDate brith;//出生日期
    private String ID;//身份证号
    private String location;//家庭住址

    public void setGender(String gender){
        if(gender.equals("男"))
            this.gender = Gender.MALE;
        else this.gender = Gender.FEMALE;
    }

    public String getGender(){
        if(this.gender == Gender.MALE)
            return "男";
        else return "女";
    }

    public Case(int number,String name,String gender,LocalDate brith,String ID,String location){
        this.number = number;
        this.name = name;
        this.brith = brith;
        this.ID  = ID;
        this.location = location;
        setGender(gender);

    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getBrith() {
        return brith;
    }

    public void setBrith(LocalDate brith) {
        this.brith = brith;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getAge(){
        LocalDate date = LocalDate.now();
        int result = date.getYear() - brith.getYear();
        if(brith.compareTo(date.minusYears(result)) > 0){
            result--;
        }
        return result;
    }
}
