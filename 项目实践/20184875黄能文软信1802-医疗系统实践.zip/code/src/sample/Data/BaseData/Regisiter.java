package sample.Data.BaseData;

public class Regisiter {
    private int caseNumber;//对应病例的病历号
    private String doctor;//对应诊断医生的ID
    private PayData data;

    public Regisiter(Case caseData,Doctor doctor,float price){
        this.caseNumber = caseData.getNumber();
        this.doctor = doctor.getID();
        this.data = PayDataManerger.get().createData(caseData,"挂号付费",price);
    }

    public int getCaseNumber() {
        return caseNumber;
    }

    public void setCaseNumber(int caseNumber) {
        this.caseNumber = caseNumber;
    }

    public String getDoctor() {
        return doctor;
    }

    public void setDoctor(String doctor) {
        this.doctor = doctor;
    }

    public boolean isPayed(){
        return data.IsPayed();
    }
}
