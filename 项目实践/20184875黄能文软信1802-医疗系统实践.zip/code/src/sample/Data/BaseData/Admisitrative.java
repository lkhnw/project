package sample.Data.BaseData;

import java.io.Serializable;

public class Admisitrative implements Serializable {
    private int ID;//编码
    private String name;//科室名字
    Constant.AD_ABILITY ability;//科室职能
    Constant.AD_KIND kind;//科室分类

    public Admisitrative(int ID, String name, Constant.AD_KIND kind,Constant.AD_ABILITY ability){
        this.ID = ID;
        this.name = name;
        this.kind = kind;
        this.ability = ability;
    }

    public int getID() {
        return ID;
    }


    public String getName() {
        return name;
    }

    public Constant.AD_ABILITY getAbility() {
        return ability;
    }

    public void setAbility(Constant.AD_ABILITY ability) {
        this.ability = ability;
    }

    public Constant.AD_KIND getKind() {
        return kind;
    }

    public void setKind(Constant.AD_KIND kind) {
        this.kind = kind;
    }

    //该科室是否参与排班
    public boolean isScheduled(){
        return kind == Constant.AD_KIND.LIN_CHUANG;
    }
}
