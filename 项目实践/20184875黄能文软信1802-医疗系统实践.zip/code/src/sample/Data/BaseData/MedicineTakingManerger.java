package sample.Data.BaseData;

import sample.TableItems.MedicineDeaItem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class MedicineTakingManerger {
    private static MedicineTakingManerger instance = null;

    public HashMap<Integer, ArrayList<MedicineDeaItem>> medicineDealList = new HashMap<>();
    public HashMap<MedicineDeaItem,PayData> medicinePayData = new HashMap<>();

    public static MedicineTakingManerger get(){
        if(instance == null)
            instance = new MedicineTakingManerger();
        return instance;
    }
    private MedicineTakingManerger(){

    }

    public Iterator<MedicineDeaItem> getMedicineItem(int num)throws Exception{
        Iterator<MedicineDeaItem> iter = medicineDealList.get(num).iterator();
        if(!iter.hasNext()) throw new Exception("不存在病号" + num);
        return iter;
    }

    public void addItem(Case caseData,MedicineDeaItem item,PayData data){
        ArrayList<MedicineDeaItem> list = medicineDealList.get(caseData.getNumber());
        if(list == null){
            list = new ArrayList<>();
            medicineDealList.put(caseData.getNumber(),list);
        }
        list.add(item);
        medicinePayData.put(item,data);
    }

    public void deleteItem(MedicineDeaItem item,int caseNumber)throws Exception{
        ArrayList<MedicineDeaItem> list = medicineDealList.get(caseNumber);
        if(list == null) throw new Exception("不存在病例 " + caseNumber);
        list.remove(item);
        medicinePayData.remove(item);
    }

    public PayData getPayData(MedicineDeaItem item){
        return medicinePayData.get(item);
    }

}
