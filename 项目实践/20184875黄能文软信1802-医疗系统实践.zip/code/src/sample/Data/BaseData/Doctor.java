package sample.Data.BaseData;

public class Doctor extends User{
    Constant.DC_LEVEL level;
    public Doctor(String name, String code, String ID,
                  Admisitrative admisitrative, Constant.DC_LEVEL level){
        super(name,code,ID, Constant.US_KIND.YI_SHENG,admisitrative);
        this.level = level;
    }

    public Constant.DC_LEVEL getLevel() {
        return level;
    }

    public void setLevel(Constant.DC_LEVEL level) {
        this.level = level;
    }
}
