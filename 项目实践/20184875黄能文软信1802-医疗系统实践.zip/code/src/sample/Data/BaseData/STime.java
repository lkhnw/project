package sample.Data.BaseData;



import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;

public class STime implements Comparable<STime>, Serializable {
    private int DATE;
    private int MONTH;
    private int YEAR;
    boolean isBeforeNoon;
    public STime(Calendar schedule){
       this.DATE = schedule.get(Calendar.DATE);
       this.MONTH = schedule.get(Calendar.MONTH);
       this.YEAR = schedule.get(Calendar.YEAR);
       isBeforeNoon = schedule.get(Calendar.HOUR) > 12;
    }



    public STime(LocalDate data, boolean isBeforeNoon){
        this.DATE = data.getDayOfMonth();
        this.MONTH = data.getMonthValue();
        this.YEAR = data.getYear();
        this.isBeforeNoon = isBeforeNoon;
    }


    public int compareTo(STime scheule){
        if(YEAR > scheule.YEAR)   return 1;
        else if(YEAR < scheule.YEAR)  return -1;
        if(MONTH > scheule.MONTH) return 1;
        else if(MONTH < scheule.MONTH) return -1;
        if(DATE > scheule.DATE) return 1;
        else if(DATE < scheule.DATE) return -1;

        if(isBeforeNoon == scheule.isBeforeNoon)
            return 0;
        else if(isBeforeNoon && !scheule.isBeforeNoon)
            return -1;
        else return 1;
    }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof  STime){
            STime item = (STime) obj;
            return item.DATE == DATE && item.MONTH == MONTH &&
                    item.YEAR == YEAR && item.isBeforeNoon == isBeforeNoon;
        }
        return false;
    }

    public String toString(){
        return YEAR + "-" +  MONTH + "-" + DATE + "-" +(isBeforeNoon ? "上午": "下午");
    }
}
