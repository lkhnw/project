package sample.Data.BaseData;

import java.util.HashMap;
import java.util.Iterator;

public class RegisiterManerger {
    private HashMap<Integer,Regisiter> list;//挂号和其所对的挂号信息的列表
    private static RegisiterManerger instance = null;

    private RegisiterManerger(){
        list = new HashMap<>();
    }
    public static RegisiterManerger get(){
        if(instance == null){
            instance = new RegisiterManerger();
        }
        return instance;
    }

    public void createRegisiter(Case caseData,Doctor doctor,float price)throws Exception{
        if(list.get(caseData.getNumber()) != null)
            throw new Exception("同一个病人不能同时挂两次号");
        list.put(caseData.getNumber(),new Regisiter(caseData,doctor,price));
    }

    public Regisiter getRegisitData(int num){
        return list.get(num);
    }

    public Iterator<Regisiter> getRegisitData(){
        return list.values().iterator();
    }

    public void deleteRegisiter(int num)throws Exception{
        if(list.get(num) != null)
            throw new Exception("无法删除，列表中没有");
    }
}
