package sample.Data.BaseData;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;

public class MenuClass implements Serializable {
    private String name;
    private String code;
    private HashMap<String,IRecord> list;

    public MenuClass(String name,String code){
        this.name = name;
        this.code = code;
        list = new HashMap<>();
    }

    public void add(String code,String name,String ICD)throws Exception{
        //加入一个疾病
        if(name == null || name.length() == 0)
            throw new Exception("该疾病的名字不能为空");
        if(list.get(name) != null)
            throw new Exception("该疾病已经存在");
        if(code == null || code.length() == 0)
            throw new Exception("疾病的编码不能为空");
        if(ICD == null || ICD.length() == 0)
            throw new Exception("该疾病的国际ICD编码不能为空");
        if(MenuManerger.get().getILL(name) != null)
            throw new Exception("此疾病已存在，不得使用此名");


        IRecord record = new IRecord(code,name,ICD,this);
        list.put(name,record);
        MenuManerger.get().save();
    }

    public void delete(String name)throws Exception{//删除一个名字为name的疾病
        if(list.get(name) == null)
            throw new Exception("不存在疾病 " + name);
        list.remove(name);
        MenuManerger.get().save();
    }

    public IRecord getRecord(String name){return list.get(name);}

    public Iterator<IRecord> getList(){
        return list.values().iterator();
    }

    public String getName() {
        return name;
    }

    public String getCode() {
        return code;
    }
}
