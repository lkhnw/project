package sample.Data.BaseData;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

public class HumanSourceManerger extends Saver{
    private Map<String,Admisitrative> admisitratives;//科室名字列表
    private Map<String,User> users;//根据ID排列的用户列表
    private Map<String, ArrayList<String>> belonging;//每个科室对应的人员ID表
    private static HumanSourceManerger instance = null;//单例
    private static final String file = "HumanSourceManerger.txt";

     private HumanSourceManerger(){
        admisitratives = new TreeMap<>();
        users = new TreeMap<>();
        belonging = new TreeMap<>();

        users.put("Root",new User("root","123456","Root", Constant.US_KIND.GUAN_LI,null));
        try {
            save(file);
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    //新建一个新的科室，名字不能重复
    public Admisitrative createAdmisitrative(
            int ID, String name, Constant.AD_ABILITY ability, Constant.AD_KIND kind)throws Exception{
        if(admisitratives.get(name) != null)
            throw new Exception("该科室已存在");
        Admisitrative temp = new Admisitrative(ID,name,kind,ability);
        admisitratives.put(temp.getName() , temp);
        belonging.put(temp.getName() , new ArrayList<>());
        save(file);
        return temp;
    }

    //添加一个用户到科室
    public User createUser(String name, String code, String ID, Constant.US_KIND kind,String adname)throws Exception{
        Admisitrative admisitrative = admisitratives.get(adname);
        if(admisitrative == null)
            throw new Exception("添加的科室不存在！！！");
        else if(users.get(ID) != null)
            throw new Exception("添加的用户的ID不能重复");
        else if(admisitrative.getKind() == Constant.AD_KIND.LIN_CHUANG  || admisitrative.getKind() == Constant.AD_KIND.YI_JI)
            throw new Exception("创建新医生请用别的方式");
        User user = new User(name,code,ID,kind,admisitrative);
        users.put(ID,user);
        ArrayList<String> item =  belonging.get(adname);
        item.add(user.getID());
        save(file);
        return user;
    }



    //创建一个医生
    public Doctor createDoctor(String name, String code, String ID, String adname, Constant.DC_LEVEL level)throws Exception{
        Admisitrative admisitrative = admisitratives.get(adname);
        if(admisitrative == null)
            throw new Exception("添加的科室不存在！！！");
        else if(users.get(ID) != null)
            throw new Exception("添加的用户的ID不能重复");
        else if(admisitrative.getKind() != Constant.AD_KIND.LIN_CHUANG  && admisitrative.getKind() != Constant.AD_KIND.YI_JI)
            throw new Exception("创建新医生请用别的方式");
        Doctor doctor = new Doctor(name,code,ID,admisitrative,level);
        users.put(doctor.getID(),doctor);
        belonging.get(adname).add(doctor.getID());
        save(file);
        return doctor;
    }


    //拿到单例的唯一实例
    public static HumanSourceManerger get()throws Exception{
        if(instance != null)
            return instance;
        else {
            Object result = read(file);
            if(result == null) {
                  instance =   new HumanSourceManerger();
                  return instance;
            }
            else
                instance =  (HumanSourceManerger) result;
            return instance;
        }
    }

    public Admisitrative getAdmisitrative(String name){
        return admisitratives.get(name);
    }

    public User getUser(String ID){
        return users.get(ID);
    }
     //添加的用户的ID不能重复
    public Iterator<User> getUserList(){
        return users.values().iterator();
    }

    public Iterator<Admisitrative> getAdmisitrativeList(){return admisitratives.values().iterator();}

    //拿到一个科室下的用户名单
    public Iterator<String> getUserList(Admisitrative ad){  return belonging.get(ad.getName()).iterator();}

    public void deleteUser(String ID)throws Exception{
        User target = users.get(ID);
        if(target == null) throw new Exception("该用户不存在！！！");
        users.remove(ID);
        Admisitrative belong = admisitratives.get(target.getAdmisitrative());
        belonging.get(belong.getName()).remove(target);
        save(file);
    }

    public void deleteAdmisitrative(String name)throws Exception {
        Admisitrative target = admisitratives.get(name);
        if(target == null) throw new Exception("要删除的科室不存在");
        admisitratives.remove(name);
        for(String user : belonging.get(target.getName())){
            users.remove(user);
        }
        belonging.remove(target.getName());
        save(file);
    }

}
