package sample.Data.BaseData;

import java.time.LocalDate;
import java.util.HashMap;

public class CaseManerger extends Saver {//这些数据是需要保存的
    private int maxNumber;
    private HashMap<Integer,Case> cases;//保管数据与病历号一一对应的列表
    private static String file = "CaseManerger.txt";
    private static CaseManerger instance = null;

    private CaseManerger(){
        cases = new HashMap<>();
    }

    public static CaseManerger get()throws Exception{
        if(instance == null){
            Object result = read(file);
            if(result == null) {
                instance = new CaseManerger();
                instance.save(file);
                instance.maxNumber = 0;
            }else instance = (CaseManerger) result;
        }
        return instance;
    }

    public Case createCase(int number, String name, String gender, LocalDate brith,String ID, String location)throws Exception{
        if(cases.get(number) != null)
            throw new Exception("不得创建重复编号的病历");
        Case data = new Case(number,name,gender,brith,ID,location);
        if(number > maxNumber) maxNumber = number;
        cases.put(number,data);
        save(file);
        return data;
    }
    //在有病号的情况下自动生成

    public void createCase(String name,String gender,LocalDate brith,String ID,String location)throws Exception{
        createCase(++maxNumber,name,gender,brith,ID,location);
    }

    public Case getCase(int num){
        return cases.get(num);
    }
}
