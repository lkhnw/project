package sample.Data.BaseData;

import java.io.Serializable;

public class User implements Serializable{
    private String name;//用户名字
    private String code;//用户密码
    private String ID;//用户ID
    Constant.US_KIND kind;//用户分类
    String admisitrative;//用户的所属科室

    public User(String name,String code,String ID,Constant.US_KIND kind,
                Admisitrative admisitrative){
        this.name = name;
        this.code = code;
        this.ID = ID;
        this.kind = kind;
        if(admisitrative != null)
            this.admisitrative = admisitrative.getName();
        else this.admisitrative = null;
    }

    public String getName() {
        return name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getID() {
        return ID;
    }


    public Constant.US_KIND getKind() {
        return kind;
    }

    public void setKind(Constant.US_KIND kind) {
        this.kind = kind;
    }

    public String getAdmisitrative() {
        return admisitrative;
    }

    public void setAdmisitrative(Admisitrative admisitrative) {
        this.admisitrative = admisitrative.getName();
    }
}
