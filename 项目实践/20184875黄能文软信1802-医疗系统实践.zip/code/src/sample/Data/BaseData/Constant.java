package sample.Data.BaseData;

public class Constant {
    public enum AD_ABILITY{NEI_KE,WAI_KE,ER_KE,PI_FU_BIN_KE,ZHONG_YI_KE,ZHONG_LIU_KE,YI_JI,QI_TA}//科室职能
    public enum AD_KIND{LIN_CHUANG,YI_JI,HOU_QING,CAI_WU}//科室分类
    public enum US_KIND{GUA_HAO,YI_SHENG,YAO_FANG,CAI_WU,GUAN_LI}//用户分类
    public enum DC_LEVEL{ZHU_YUAN,ZHU_ZHI,FU_ZHU_REN,ZHU_REN}//医生职称
    public enum RG_LEVEL{ZHUAN_JIA,PU_TONG,JI_ZHEN}
    private static int[] RG_PRICE = {40,60,80};
    private static int[] RG_LIMIT = {30,20,10};



    public static String getString(AD_ABILITY ab){
        if(ab == AD_ABILITY.NEI_KE) return "内科";
        else if(ab == AD_ABILITY.WAI_KE) return "外科";
        else if(ab == AD_ABILITY.ER_KE) return "儿科";
        else if(ab == AD_ABILITY.PI_FU_BIN_KE) return "皮肤病科";
        else if(ab == AD_ABILITY.ZHONG_LIU_KE) return "肿瘤科";
        else if(ab == AD_ABILITY.ZHONG_YI_KE) return "中医科";
        else if(ab == AD_ABILITY.YI_JI) return "医技科";
        else if(ab == AD_ABILITY.QI_TA) return "其它科";
        return null;
    }
    public static AD_ABILITY getADAbility(String kind)throws Exception{
        if(kind.equals("内科")) return AD_ABILITY.NEI_KE;
        else if(kind.equals("外科")) return AD_ABILITY.WAI_KE;
        else if(kind.equals("儿科")) return AD_ABILITY.ER_KE;
        else if(kind.equals("皮肤病科")) return AD_ABILITY.PI_FU_BIN_KE;
        else if(kind.equals("中医科")) return AD_ABILITY.ZHONG_YI_KE;
        else if(kind.equals("肿瘤科")) return AD_ABILITY.ZHONG_LIU_KE;
        else if(kind.equals("医技科"))  return AD_ABILITY.YI_JI;
        else if(kind.equals("其他科")) return AD_ABILITY.QI_TA;
        throw new Exception(kind + "是不存在的类型");
    }

    public static String[] listAbility(){
        String[] result = {"内科","外科","儿科","皮肤病科","中医科","肿瘤科","医技科","其他科"};
        return result;
    }


    //返回科室分类所对应的名称的函数
    public static String getString(AD_KIND kind){
        if(kind == AD_KIND.LIN_CHUANG) return "临床";
        else if(kind == AD_KIND.YI_JI) return "医技";
        else if(kind == AD_KIND.CAI_WU) return "财务";
        else if(kind == AD_KIND.HOU_QING) return "后勤";
        return null;
    }

    public static AD_KIND getADKind(String kind)throws Exception{
        if(kind.equals("临床")) return AD_KIND.LIN_CHUANG;
        else if(kind.equals("医技")) return AD_KIND.YI_JI;
        else if(kind.equals("财务")) return AD_KIND.CAI_WU;
        else if(kind.equals("后勤")) return AD_KIND.HOU_QING;
        throw new Exception(kind + "是不存在的类型");
    }

    public static String[] listADKind(){
        String[] str = {"临床","医技","财务","后勤"};
        return str;
    }


    public static String getString(US_KIND kind){
        if(kind == US_KIND.GUA_HAO) return "挂号";
        else if(kind == US_KIND.YI_SHENG) return "医生";
        else if(kind == US_KIND.YAO_FANG) return "药房";
        else if(kind == US_KIND.CAI_WU) return "财务";
        else if(kind == US_KIND.GUAN_LI) return "管理";
        return null;
    }
    public static US_KIND getUserKind(String kind)throws Exception{
        if(kind.equals("挂号")) return US_KIND.GUA_HAO ;
        else if(kind.equals("药房")) return US_KIND.YAO_FANG;
        else if(kind.equals("财务")) return US_KIND.CAI_WU;
        else if(kind.equals("管理")) return US_KIND.GUAN_LI;
        else if(kind.equals("医生")) return US_KIND.YI_SHENG;
        throw new Exception( kind + "是不存在的用户类型");
    }
    public static String[] listUserKind(){
        String[] result = {"挂号","药房","财务","管理","医生"};
        return result;
    }

    public static String getString(DC_LEVEL level){
        if(level == DC_LEVEL.ZHU_ZHI) return "主治医生";
        else if(level == DC_LEVEL.ZHU_YUAN) return "住院医生";
        else if(level == DC_LEVEL.FU_ZHU_REN) return "副主任";
        else if(level == DC_LEVEL.ZHU_REN) return "主任";
        return null;
    }
    public static DC_LEVEL getDoctorLevel(String level)throws Exception{
        if(level.equals("主治医生")) return DC_LEVEL.ZHU_ZHI;
        else if(level.equals("住院医生")) return DC_LEVEL.ZHU_YUAN;
        else if(level.equals("副主任")) return DC_LEVEL.FU_ZHU_REN;
        else if(level.equals("主任")) return DC_LEVEL.ZHU_REN;
        throw new Exception(level + "是不存在的用户类型");
    }
    public static String[] listDoctorLevel(){
        String[] result = {"主治医生","住院医生","副主任","主任"};
        return result;
    }

    public static String getString(RG_LEVEL level){
        if(level == RG_LEVEL.PU_TONG) return "普通号";
        else if(level == RG_LEVEL.ZHUAN_JIA) return "专家号";
        else if(level == RG_LEVEL.JI_ZHEN) return "急诊号";
        return null;
    }

    public static RG_LEVEL getRegisiterLevel(String level)throws Exception{
        if(level.equals("普通号")) return RG_LEVEL.PU_TONG;
        else if(level.equals("专家号")) return RG_LEVEL.ZHUAN_JIA;
        else if(level.equals("急诊号")) return RG_LEVEL.JI_ZHEN;
        throw new Exception(level + "是不存在的类型");
    }

    public static String[] listRegisiterLevel(){
        String[] result = {"普通号","专家号","急诊号"};
        return result;
    }

    //根据医生的职称判断挂号等级
    public static RG_LEVEL fromDCtoRG(DC_LEVEL level){
        if(level == DC_LEVEL.ZHU_YUAN || level == DC_LEVEL.ZHU_ZHI)
            return RG_LEVEL.PU_TONG;
        else if(level == DC_LEVEL.FU_ZHU_REN)
            return RG_LEVEL.ZHUAN_JIA;
        else if(level == DC_LEVEL.ZHU_REN)
            return RG_LEVEL.JI_ZHEN;
        return null;
    }

    private static int getNum(RG_LEVEL level,int[] list){
        if(level == RG_LEVEL.PU_TONG) return list[0];
        else if(level == RG_LEVEL.ZHUAN_JIA) return list[1];
        else if(level == RG_LEVEL.JI_ZHEN) return list[2];
        return -1;
    }

    //得到对应挂号的价格
    public static int getRGprice(RG_LEVEL level){
        return getNum(level,RG_PRICE);
    }
    //得到对应挂号的限额
    public static int getRGlimit(RG_LEVEL level){
        return getNum(level,RG_LIMIT);
    }

}
