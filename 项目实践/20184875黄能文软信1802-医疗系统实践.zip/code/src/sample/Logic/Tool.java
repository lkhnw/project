package sample.Logic;

import javafx.scene.control.*;

import java.time.DayOfWeek;

public class Tool {

    //可以让字符串重新组织自然分段
    public static String organize(String target,int maxLine){
        int end = maxLine,begin = 0;
        boolean flag = false;
        String result = "";
        for(int i = 0;i != target.length();i++){
            if(target.charAt(i) == '\n'){
                result += target.substring(begin,i + 1);
                begin = i + 1;
                end = begin + maxLine;
            }else if(i == end){
                result += target.substring(begin,end) + "\n";
                begin = i;
                end = i + maxLine;
            }
        }
        result += target.substring(begin);

        return result;
    }

    public static String getNotEmptyInput(TextField input)throws Exception{
        String result = input.getText();
        if(result.length() == 0 || result == null)
            throw new Exception("输入不能为空");
        return result;
    }

    public static int getWeekDay(DayOfWeek date){
        if(date == DayOfWeek.MONDAY)
            return 1;
        else if(date == DayOfWeek.TUESDAY)
            return 2;
        else if(date == DayOfWeek.WEDNESDAY)
            return 3;
        else if(date == DayOfWeek.THURSDAY)
            return 4;
        else if(date == DayOfWeek.FRIDAY)
            return 5;
        else if(date == DayOfWeek.SATURDAY)
            return 6;
        else
            return 0;
    }

    public static String getNotEmptyInput(ComboBox<String> choice)throws Exception{
        String str = choice.getValue();
        if(str == null || str.length() == 0)
            throw new Exception("不得输入为空");
        return str;
    }

}
