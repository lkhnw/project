package sample.Logic;

import javafx.scene.Node;
import javafx.scene.control.*;

import java.util.ArrayList;

//用来应付程序可能平繁出现的提示框
public class IntroductionNotifier {
    private TextArea introduction;
    private Node notifier;//和提示相关的按钮
    private String content;//相关的提示

    private static ArrayList<IntroductionNotifier> list = new ArrayList<>();


    public IntroductionNotifier(
            TextArea introduction,Node notifier,String content){
        this.introduction = introduction;
        this.notifier = notifier;
        this.content = content;
        notifier.setOnMouseEntered(e->{
            introduction.setText(content);
        });
        notifier.setOnMouseExited(e->{
            introduction.clear();
        });
    }

    public static void setNotify(TextArea introduction,Node notifier,String content){
        notifier.setOnMouseEntered(e->{
            introduction.setText(content);
        });
        notifier.setOnMouseExited(e->introduction.clear());
    }

    public static void setNotify(TextArea introduction,Node notifier,String content,int maxLine){
        setNotify(introduction,notifier,Tool.organize(content,maxLine));
    }



}
