package sample.Logic;


import sample.Data.BaseData.HumanSourceManerger;
import sample.Data.BaseData.User;

public class LoginManerger {
    private HumanSourceManerger manerger;
    private User user = null;
    private static LoginManerger instance = null;
    private LoginManerger()throws Exception{
        manerger = HumanSourceManerger.get();
    }
    public static LoginManerger get()throws Exception{
        if(instance == null){
            instance = new LoginManerger();
        }
        return instance;
    }

    public void login(String userName,String code)throws Exception{
        User user = manerger.getUser(userName);
        if(user == null) throw new Exception("用户名不存在！！！！");
        if(user.getCode().equals(code)){
            this.user = user;
        }else{
            throw new Exception("用户密码输入错误!!!!");
        }
    }


    public void logOut(){
        user = null;
    }

    public User getUser(){
        return user;
    }
}
