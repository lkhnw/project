package sample;

import com.sun.javafx.robot.impl.FXRobotHelper;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import sample.Data.BaseData.Admisitrative;
import sample.Data.BaseData.Constant;
import sample.Data.BaseData.Doctor;
import sample.Data.BaseData.HumanSourceManerger;
import sample.Logic.IntroductionNotifier;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.ResourceBundle;

public class AddUser implements Initializable {
    public TextField nameInput;
    public TextField IDInput;
    public TextField codeInput;
    public ComboBox<String> occupyBox;
    //用户对应的职业，非医生不会有对应的
    public ComboBox<String> doctotLevelList;
    public ComboBox<String> admisitrativeList;
    public Text doctorLevel;
    public Text admisitrative;
    public TextArea introduction;
    private HashMap<String,String> introductionList = new HashMap<>();
    //开始隐藏起来的选项
    //只有当用户选择完职业以后才会显示

    private ArrayList<IntroductionNotifier> notifiers = new ArrayList<>();
    //会出现提示的节点列表

    void initIntroductionList(){
         /*introductionList.put("nameInput","输入用户真实名字\n不同用户的名字可以重名\n此项必填");
         introductionList.put("IDInput", "输入用户的登陆名(ID)\n用户的ID不得重复\n此项必填");
         introductionList.put("codeInput","输入用户的密码\n不同用户的密码可以重复\n此项必填");
         introductionList.put("occupyInput",);
         introductionList.put("doctorLevel","当用户是医生时选择医生的职称\n注意，只有当用户是医生时才会有此选项");
         introductionList.put("admisitrative","选择用户的科室，从现有科室中选择\n只有当用户是医生是才会出现临床和医技科的选项");*/
         notifiers.add(new IntroductionNotifier(introduction,occupyBox,"选择用户的职阶" +
                                                                                    "\n用户的职阶不同接下来选择的内容选项可能不同！！！" +
                                                                                        "\n请注意默认值为 " + Constant.listDoctorLevel()[0]));
         notifiers.add(new IntroductionNotifier(introduction,nameInput,"输入用户真实名字" +
                                                                                    "\n不同用户的名字可以重名" +
                                                                                              "\n此项必填"));
         notifiers.add(new IntroductionNotifier(introduction,IDInput,"输入用户的登陆名(ID)" +
                                                                                     "\n用户的ID不得重复" +
                                                                                          "\n此项必填"));
         notifiers.add(new IntroductionNotifier(introduction,codeInput,"输入用户的密码" +
                                                                                        "\n不同用户的密码可以重复" +
                                                                                             "\n此项必填"));
         notifiers.add(new IntroductionNotifier(introduction,doctotLevelList,"当用户是医生时选择医生的职称" +
                                                                                            "\n注意，只有当用户是医生时才会有此选项"));
         notifiers.add(new IntroductionNotifier(introduction,admisitrativeList,"选择用户的科室，从现有科室中选择" +
                 "                                                                         \n只有当用户是医生是才会出现临床和医技科的选项"));
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        initIntroductionList();
        String[] userKindList = Constant.listUserKind();
        for(int i = 0;i != userKindList.length;i++)
            occupyBox.getItems().add(userKindList[i]);

        setDoclevelAndAdList(false,false);
    }


   public void onExitButtonPushed(){
       try{
           SceneChanger.get().loadScene("main");
       }catch(Exception e){
           AlertBox.display(e.getMessage(),"转场时错误");
       }
   }

   //当职称选择了之后,医生只能在医技或临床科中,其它职阶不允许在这两科中
    public void onOccupySelected(){
       try {
           setDoclevelAndAdList(false,false);
           doctotLevelList.getItems().clear();
           admisitrativeList.getItems().clear();//开始将两个列表清空
           Constant.US_KIND kind = Constant.getUserKind(occupyBox.getValue());
           if(kind == Constant.US_KIND.YI_SHENG){

               setDoclevelAndAdList(true,true);

               Iterator<Admisitrative> adList = HumanSourceManerger.get().getAdmisitrativeList();
               if(!adList.hasNext()) {//可能可用的科室一个都没有
                   AlertBox.display("不存在可用的科室！！！","输入时错误");

                   setDoclevelAndAdList(false,false);
               }
               else{
                   while (adList.hasNext()) {
                       Admisitrative current = adList.next();
                       if (current.getKind() == Constant.AD_KIND.LIN_CHUANG ||
                               current.getKind() == Constant.AD_KIND.YI_JI)
                           admisitrativeList.getItems().add(current.getName());
                   }
                   //将默认值设为第0个
                   admisitrativeList.setValue(admisitrativeList.getItems().get(0));
               }

               String[] fullDoctorLevelList = Constant.listDoctorLevel();
               for(int i = 0;i != fullDoctorLevelList.length;i++){
                   doctotLevelList.getItems().add(fullDoctorLevelList[i]);
               }
               doctotLevelList.setValue(fullDoctorLevelList[0]);
           }else{//如果不是医生的话(两块有不少地方相似，最喜欢抄代码了，抄抄抄！！！)
               setDoclevelAndAdList(false,true);

               Iterator<Admisitrative> adList = HumanSourceManerger.get().getAdmisitrativeList();
               if(!adList.hasNext()) {//可能可用的科室一个都没有
                   AlertBox.display("不存在可用的科室！！！","输入时错误");
                   setDoclevelAndAdList(false,false);
               }
               else{
                   while (adList.hasNext()) {
                       Admisitrative current = adList.next();
                       if (current.getKind() != Constant.AD_KIND.LIN_CHUANG &&
                               current.getKind() != Constant.AD_KIND.YI_JI)
                           admisitrativeList.getItems().add(current.getName());
                   }
                   //将默认值设为第0个
                   admisitrativeList.setValue(admisitrativeList.getItems().get(0));
               }
           }
       }catch(Exception e){
           AlertBox.display(e.getMessage(),"选择职业时错误");
       }
    }

    public void onAddButtonPushed(){
       String name = nameInput.getText();
       if(name == null || name.length() == 0){
           AlertBox.display("姓名不能为空！！","创建时错误");
           return;
       }
       String ID = IDInput.getText();
       if(ID == null || name.length() == 0){
           AlertBox.display("用户ID不能为空!!","创建时错误");
           return;
       }
       String code = codeInput.getText();
       if(code == null || name.length() == 0){
           AlertBox.display("用户密码不能为空！！！","创建时错误");
           return;
       }

       try{
           String admisitrative = admisitrativeList.getValue();
           Constant.US_KIND kind = Constant.getUserKind(occupyBox.getValue());
           if(kind == Constant.US_KIND.YI_SHENG){
               Constant.DC_LEVEL level = Constant.getDoctorLevel(doctotLevelList.getValue());
               HumanSourceManerger.get().createDoctor(name,code,ID,admisitrative, level);
               SceneChanger.get().loadScene("main");
           }else {
               HumanSourceManerger.get().createUser(name, code, ID, kind, admisitrative);
               SceneChanger.get().loadScene( "main");
           }
       }catch(Exception e){
           AlertBox.display(e.getMessage(),"创建时错误");
       }
    }
    //设置窗口是否可见
    private void setDoclevelAndAdList(boolean docLevel,boolean AdList){
          doctotLevelList.setVisible(docLevel);
          doctorLevel.setVisible(docLevel);
          admisitrativeList.setVisible(AdList);
          admisitrative.setVisible(AdList);
    }

}
