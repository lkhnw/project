package sample;

import com.sun.javafx.robot.impl.FXRobotHelper;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import sample.Data.BaseData.*;
import sample.Logic.LoginManerger;
import sun.reflect.generics.tree.Tree;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.ResourceBundle;

public class SceneDataMain implements Initializable {
     public TreeView<String> tree;

     public Button Enter;
     public Button Exit;
     //public TextArea texts;

     private String current = "欢迎";

     private HashMap<String,String>  introductionList = new HashMap<>();

     private HashMap<String,String>  sceneList = new HashMap<>();

     private final static int facilityNum = 1;//访问设施总数
     private SceneItem[] facilities = new SceneItem[facilityNum];

     private HashMap<Constant.US_KIND, int[]> powerTable = new HashMap<>();//访问权限表





     private void initPowerList(){//初始化权限表
         //facilities[0] = new BasicDataItem();
         facilities[0] = new RegisitItem();
         //facilities[1] = new ClinitItem();
         //facilities[1] = new DoctorItem();
                             //对基础数据权限  //对挂号交费数据的权限  //对药房数据的权限 //对医生看诊的权限
         int[] doctorList   = {0             ,0                     ,0                ,1               };//在这里修改医生的权限
         powerTable.put(Constant.US_KIND.YI_SHENG,doctorList);
         int[] governerList = {1             ,1                     ,1                ,1               };//在这里修改管理者的权限
         powerTable.put(Constant.US_KIND.GUAN_LI,governerList);
         int[] moneyList    = {0             ,0                     ,0                ,0               };//在这里修改财务的权限
         powerTable.put(Constant.US_KIND.CAI_WU,moneyList);
         int[] registerList = {0             ,1                     ,0                ,0               };//在这里修改挂号的权限
         powerTable.put(Constant.US_KIND.GUA_HAO,registerList);
         int[] clinitList   = {0             ,0                     ,1                ,0               };//在这里修改药房的权限
         powerTable.put(Constant.US_KIND.YAO_FANG,clinitList);
     }

     void setPower()throws Exception{
         Constant.US_KIND kind = LoginManerger.get().getUser().getKind();//拿到当前登陆用户的类型
         int[] power = powerTable.get(kind);//由权限
         for(int i  = 0;i != facilityNum;i++){
             facilities[i].IsActivated = (power[i] != 0);
         }//设置权限
     }//设置当前用户的权限

     void setTree(){
        TreeItem<String> root = new TreeItem<>();
        root.setExpanded(true);
        for(int i = 0;i != facilityNum;i++){
            if(facilities[i].IsActivated)
                root.getChildren().add(facilities[i].create());
        }
        for(int i = 0;i != root.getChildren().size();i++){
            root.getChildren().get(i).setExpanded(true);
        }
        tree.setRoot(root);
     }//根据权限设置开放的视图




     //在添加场景的时候要向这里添加相应的视图和跳转方式
     private void initList(){
         try {
             introductionList.put("欢迎", "【"+ LoginManerger.get().getUser().getName()+"】,欢迎来到东软医疗管理系统，你现在的权限是【" +
                     Constant.getString(LoginManerger.get().getUser().getKind()) + "】\n"
             + "左边这些功能已经开放,选择后查看详情，点击进入进入该模块");

             introductionList.put("加入用户","新加入一个用户在系统中。 \n需要提供用户的账户(ID)，密码，实名等等详细信息，每个用户的账户不能重复。\n");
             sceneList.put("加入用户" , "add_user" );

             introductionList.put("删除用户","删除系统中的一个用户。   \n需提供他的ID信息");
             sceneList.put("删除用户","delete_user");

             introductionList.put("添加科室","添加一个新的科室在系统中。\n需要提供科室的一些具体信息,科室的名字不能重复");
             sceneList.put("添加科室","add_ad");

             introductionList.put("删除科室","删除已经存在的科室。\n 需要提供科室的名字");
             sceneList.put("删除科室","delete_ad");

             introductionList.put("管理疾病数据","管理当前记录在案的疾病数据\n有添加，查找，删除等功能");
             sceneList.put("管理疾病数据","ill_manerge");

             introductionList.put("管理排班信息","管理当前医生的排班信息");
             sceneList.put("管理排班信息","schedule");

             introductionList.put("挂号","挂号员为当前来的患者进行挂号操作");
             sceneList.put("挂号","addregisit");

             introductionList.put("收费","挂号员对某病例的收费操作");
             sceneList.put("收费","charge");

             introductionList.put("管理药品","管理当前登记在案的药品");
             sceneList.put("管理药品","medicine_manerge");

             introductionList.put("医生看诊","医生对病人进行看诊的操作");
             sceneList.put("医生看诊","doctor_deal");

             introductionList.put("发放药品","药房工作人员进行发放药品的工作");
             sceneList.put("发放药品","take_medicine");

         }catch(Exception e){
             AlertBox.display(e.getMessage(),"主界面");
         }
     }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
         try {
             initPowerList();//初始化权限表
             setPower();//设置权限
             setTree();//初始化树状视图
         }catch(Exception e){
             AlertBox.display(e.getMessage(),"权限列表初始化失败");
         }


        initList();

                tree.getSelectionModel().selectedItemProperty().addListener((v,oldData,newData)->{
                    String data = introductionList.get(newData.getValue());
                    if(data != null) {
                        //texts.setText(data);
                        current = newData.getValue();
            }else{
                current = "欢迎";
                //texts.setText(introductionList.get("欢迎"));
            }
        });


        //texts.setText(introductionList.get("欢迎"));

    }

    public void onExitPush(){
         try {
             SceneChanger.get().loadScene( "log_in");
         }catch(Exception e){
             AlertBox.display(e.getMessage(),"转场时错误");
         }
    }

    public void onEnterPush(){
         try{
             SceneChanger.get().loadScene(sceneList.get(current));
         }catch(Exception e){
             AlertBox.display(e.getMessage(),"转场时的错误");
        }
    }


}
abstract class SceneItem{
    public boolean IsActivated = true;
    public abstract TreeItem<String> create();

    protected TreeItem<String> makeChild(String tag,TreeItem father){
        TreeItem<String> node = new TreeItem<>(tag);
        father.getChildren().add(node);
        return node;
    }
}
class BasicDataItem extends SceneItem{
    public TreeItem<String> create(){
        TreeItem<String> root = new TreeItem<>("基本数据管理");

        makeChild("加入用户",root);
        makeChild("删除用户",root);
        makeChild("添加科室",root);
        makeChild("删除科室",root);
        makeChild("管理疾病数据",root);
        makeChild("管理排班信息",root);


        return root;
    }
}
class RegisitItem extends  SceneItem{
    public TreeItem<String> create(){
        TreeItem<String> root = new TreeItem<>( "");
        //makeChild("添加科室",root);
        //makeChild("加入用户",root);
        makeChild("挂号",root);
        makeChild("收费",root);
        //makeChild("管理药品",root);
        makeChild("发放药品",root);
        makeChild("医生看诊",root);
        return root;
    }
}
class ClinitItem extends SceneItem{
    public TreeItem<String> create(){
        TreeItem<String> root = new TreeItem<>("药房管理");

        makeChild("管理药品",root);
        makeChild("发放药品",root);
        return root;
    }
}

class DoctorItem extends SceneItem{
    public TreeItem<String> create(){
        TreeItem<String> root = new TreeItem<>("医生看诊");

        makeChild("医生看诊",root);
        return root;
    }
}