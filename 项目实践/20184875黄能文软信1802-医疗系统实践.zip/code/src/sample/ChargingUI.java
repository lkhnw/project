package sample;

import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import sample.Data.BaseData.Case;
import sample.Data.BaseData.CaseManerger;
import sample.Data.BaseData.PayData;
import sample.Data.BaseData.PayDataManerger;
import sample.Logic.IntroductionNotifier;
import sample.Logic.Tool;
import sample.TableItems.PayingTableItem;

import java.net.URL;
import java.util.Iterator;
import java.util.ResourceBundle;

public class ChargingUI implements Initializable {

    public TextField caseNumInput;
    public TextField name;//不可改
    public TextField age;//不可改
    public TextField gender;
    public TextField IdCode;//不可改
   // public TextArea introduction;

    public TableView<PayingTableItem> table;
    public TableColumn<PayingTableItem,String> caseNameLine;
    public TableColumn<PayingTableItem,String> subjectNameLine;
    public TableColumn<PayingTableItem, Float> priceLine;
    public TableColumn<PayingTableItem, Button> operationLine;

    private int maxLine = 27;

    public void refresh() {//对窗口的刷新
        try{
            int caseNumber = Integer.parseInt(Tool.getNotEmptyInput(caseNumInput));


            Case caseData = CaseManerger.get().getCase(caseNumber);
            name.setText(caseData.getName());
            IdCode.setText(caseData.getID());
            age.setText(Integer.toString(caseData.getAge()));
            gender.setText(caseData.getGender());

            Iterator<PayData> list = PayDataManerger.get().getData(caseNumber);

            table.getItems().clear();//对列表数据更新之前清空列表
            while(list.hasNext()){
                PayData data = list.next();
                if(!data.IsPayed()){
                    table.getItems().add(new PayingTableItem(data,this));
                }
            }

        }catch(Exception e){
            AlertBox.display(e.getMessage(),"在刷新窗口的时候出现错误");
        }
    }

    /*private void initIntroduction(){
        IntroductionNotifier.setNotify(introduction,caseNumInput, Tool.organize("在这里输入需要付费的病例号\n" +
                                                                               "输入完成后点击查询就可在下方姓名，年龄，身份证号框中查看到当前该病历号对应信息\n"
                                                                                  + "在最下面的列表中中可以看到查询到的该病例的所有付费项目",maxLine));
        IntroductionNotifier.setNotify(introduction,name,
                Tool.organize("输入病历号点击查询后\n就可以看到对应病例的姓名(如果查的到)\n",maxLine));
        IntroductionNotifier.setNotify(introduction,age,
                Tool.organize("输入病历号点击查询后\n就可以在这里看到查到的年龄(如果查得到的话)\n",maxLine));
        IntroductionNotifier.setNotify(introduction,gender,
                Tool.organize("输入病历号点击查询后\n就可以在后面看到对应病例的性别(如果查得到的话)",maxLine));
        IntroductionNotifier.setNotify(introduction,IdCode,
                Tool.organize("输入病历号点击查询后\n就可以在后面看到对应病例的身份证号",maxLine));
        IntroductionNotifier.setNotify(introduction,table,
                Tool.organize("输入病例号点击查询后\n" +
                        "可以看到当前病例下的所有收费项目\n" +
                        "如要对一个项目收费点击后面的收费即可记录下该项目的收费状态",maxLine));

    }*/

    private void initColmns(){//初始化列表的列
        caseNameLine.setCellValueFactory(new PropertyValueFactory<>("caseName"));
        subjectNameLine.setCellValueFactory(new PropertyValueFactory<>("name"));
        priceLine.setCellValueFactory(new PropertyValueFactory<>("price"));
        operationLine.setCellValueFactory(new PropertyValueFactory<>("operation"));
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        //initIntroduction();
        initColmns();
    }

    public void onSearchButtonPushed(){
        refresh();
    }

    public void exit(){
        try{
            SceneChanger.get().loadScene("main");
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"转场时出现错误");
        }
    }


}
