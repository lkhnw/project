package sample;

import com.sun.javafx.robot.impl.FXRobotHelper;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import sample.Data.BaseData.*;


import java.net.URL;
import java.util.ResourceBundle;

public class AddAdmisitrative implements Initializable {
     public TextField adNameInput;
     public TextField adIDInput;
     public ComboBox<String> kindChoice;
     public ComboBox<String> adChoice;
     public TextArea introdution;

     public void onExitPushed(){
         try{
             SceneChanger.get().loadScene("main");
         }catch(Exception e){
             AlertBox.display(e.getMessage(),"转场时的错误");
         }
     }

     //老版本的做法比较蠢

     public void onNameInputSelected(){
         introdution.setText("想要添加的科室的名字\n名字不能为空，且不能与其它科室重名\n");
     }
     public void onIDInputSelected(){
         introdution.setText("想要添加的科室的编码\n编码不得为空且不得重复\n编码必须为数字");
     }
     public void onKindChoiceSelected(){
         introdution.setText("选择添加的科室的职能\n职能主要由科室的工作性质决定，如临床，医技等等\n科室的职能初始设定为" + Constant.listADKind()[0]);

     }
     public void onAbChoiceSelected(){
         introdution.setText("选择要添加的科室的类型\n科室的类型由科室的工作内容决定，如儿科，内科等等\n科室的类型初始设定为" + Constant.listUserKind()[0]);
     }



     public void onEnterPushed(){
         String name = adNameInput.getText();
         if(name == null  || name.length() == 0) {
             AlertBox.display("用户名不能为空！！","添加时出错");
             return;
         }
         String id = adIDInput.getText();
         if(id == null || id.length() == 0){
             AlertBox.display("用户ID不能为空！！","添加时出错");
             return;
         }
         try {
             Constant.AD_KIND kind = Constant.getADKind(kindChoice.getValue());
             Constant.AD_ABILITY ability = Constant.getADAbility(adChoice.getValue());
             HumanSourceManerger.get().createAdmisitrative(Integer.parseInt(id),name,ability,kind);
             SceneChanger.get().loadScene("main");
         }catch(NumberFormatException e){
             AlertBox.display("科室的编码得是数字！！！","在添加用户时的错误");
         } catch(Exception e){
             AlertBox.display(e.getMessage(),"在添加用户时的错误");
         }

     }


     //清除介绍内容
     public void  clearIntroduction(){
         introdution.clear();
     }



     @Override
    public void initialize(URL location, ResourceBundle resouce){
         try{
             String[] kindList = Constant.listADKind();
             String[] abilityList = Constant.listAbility();
             for(int i = 0;i != kindList.length;i++){
                 kindChoice.getItems().add(kindList[i]);
             }
             kindChoice.setValue(kindList[0]);
             for(int i = 0;i != abilityList.length;i++){
                 adChoice.getItems().add(abilityList[i]);
             }
             adChoice.setValue(abilityList[0]);
         }catch(Exception e){

         }
     }

}
