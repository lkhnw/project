package sample;

import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import sample.Data.BaseData.Case;
import sample.Data.BaseData.CaseManerger;
import sample.Data.BaseData.MedicineTakingManerger;
import sample.Logic.IntroductionNotifier;
import sample.Logic.Tool;
import sample.TableItems.MedicineDeaItem;
import sample.TableItems.MedicineDealButtonItem;

import java.net.URL;
import java.util.Iterator;
import java.util.ResourceBundle;

public class TakingMedicineUI implements Initializable {

    public TextField caseNumberInput;
    public TextField currentName;
    public TextField currentAge;
    public TextField currentGender;

    public TableView<MedicineDealButtonItem> medicineList;
    public TableColumn<MedicineDealButtonItem,String> nameList;
    public TableColumn<MedicineDealButtonItem,Integer> numberList;
    public TableColumn<MedicineDealButtonItem,String> unitList;
    public TableColumn<MedicineDealButtonItem, Button> operationList;

    //public TextArea introduction;

    private final int maxLine = 15;

    private void loadMedicineList(int caseNum) {
        try {
            medicineList.getItems().clear();
            Iterator<MedicineDeaItem>  iter = MedicineTakingManerger.get().getMedicineItem(caseNum);
            while(iter.hasNext()){
                MedicineDeaItem item = iter.next();
                if(MedicineTakingManerger.get().getPayData(item).IsPayed()){
                    medicineList.getItems().add(new MedicineDealButtonItem(item,this));
                }
            }
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"错误");
        }
    }

   /* private void initIntroduction(){
        IntroductionNotifier.setNotify(introduction,caseNumberInput,"在此处输入想要领取药品患者的病例号\n" +
                "点击查询按钮后可以查询换者的具体信息和当前待领取的药品",maxLine);
        IntroductionNotifier.setNotify(introduction,medicineList,"在上方输入患者的病历号和名字并查询后可以在此处看到结果\n" +
                "在每条结果的最后面点击领取可以领取相应的药物",maxLine);
    }*/

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        nameList.setCellValueFactory(new PropertyValueFactory<>("name"));
        numberList.setCellValueFactory(new PropertyValueFactory<>("num"));
        unitList.setCellValueFactory(new PropertyValueFactory<>("unit"));
        operationList.setCellValueFactory(new PropertyValueFactory<>("Take"));

        //initIntroduction();

    }

    public void onSearchPushed(){
        try {
            int number = Integer.parseInt(Tool.getNotEmptyInput(caseNumberInput));
            Case caseData = CaseManerger.get().getCase(number);
            currentName.setText(caseData.getName());
            currentAge.setText(caseData.getAge() + "");
            currentGender.setText(caseData.getGender());
            loadMedicineList(caseData.getNumber());
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"错误");
        }
    }

    public void onTakeButtonPushed(MedicineDealButtonItem item) {
        try {
            medicineList.getItems().remove(item);
            MedicineTakingManerger.get().deleteItem(item.getItem(), Integer.parseInt(caseNumberInput.getText()));
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"错误");
        }
    }



    public void exit(){
        try{
            SceneChanger.get().loadScene("main");
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"转换时错误");
        }
    }

}
