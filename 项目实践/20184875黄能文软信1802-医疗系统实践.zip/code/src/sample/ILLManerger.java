package sample;

import com.sun.javafx.font.freetype.HBGlyphLayout;
import com.sun.javafx.robot.impl.FXRobotHelper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;


import sample.Data.BaseData.IRecord;
import sample.Data.BaseData.MenuClass;
import sample.Data.BaseData.MenuManerger;
import sample.Logic.IntroductionNotifier;
import sample.Logic.Tool;

import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.ResourceBundle;

public class ILLManerger implements Initializable {
    static final String ALL = "全选";
    static final String NULL = "无";


    //查找部分的组件
    public ComboBox<String> sreachMenu;
    public TextField sreachInput;



    //添加部分的组件
    public ComboBox<String> addILLMenuChoice;
    public TextField inputILLName;
    public TextField inputILLCode;
    public TextField inputILLICD;
    public TextField inputMenuName;
    public TextField inputMenuCode;

    //介绍部分的组件
    public TextArea introduction;

    //列表组件
    public TableView<IRecord> table;

    //删除模块
    public ComboBox<String> deleteMenuInput;
    public TextField deleteILLInput;


    private String currentMenu = ALL;//当前选中的目录
    private String currentILL = ALL;//当前选中的疾病
    private ArrayList<IntroductionNotifier> list = new ArrayList<>();

    public TableColumn<IRecord,String> nameLine;
    public TableColumn<IRecord,String> codeLine;
    public TableColumn<IRecord,String> ICDLine;
    public TableColumn<IRecord,String> classLine;

    private void initIntroduction(){
        final int lineMax = 10;


        list.add(new IntroductionNotifier(introduction,sreachMenu,
                Tool.organize("在筛选栏中选择需要筛选的目录\n选中之后会在屏幕上显示该目录下所有疾病名称\n默认状态下选中的是全选",lineMax)));
        list.add(new IntroductionNotifier(introduction,sreachInput,
                Tool.organize("在查找栏中输入想要选择的疾病的名字\n" +
                                                                                 "输入后点击【查找】开始查找,在左方显示结果\n",lineMax)));
        list.add(new IntroductionNotifier(introduction,addILLMenuChoice,Tool.organize("选择添加疾病时所属的分类\n" +
                                                                                     "只能选择已有的分类\n",lineMax)));
        list.add(new IntroductionNotifier(introduction,inputILLName, Tool.organize("添加疾病的名字\n" +
                                                                                 "每个疾病的名字不能重复\n",lineMax)));
        list.add(new IntroductionNotifier(introduction,inputILLCode,Tool.organize("添加疾病的助记码\n"
                                                                               + "每个疾病的主机码只能不同\n",lineMax)));
        list.add(new IntroductionNotifier(introduction,inputILLICD,Tool.organize("添加每个疾病的ICD标记码\n" +
                                                                                 "每个疾病的ICD标记码必须不同\n",lineMax)));
        list.add(new IntroductionNotifier(introduction,inputMenuName,Tool.organize("要添加的疾病目录的类名\n"
                                                                                  + "每个疾病目录类名都不相同\n",lineMax)));
        list.add(new IntroductionNotifier(introduction,inputMenuCode,Tool.organize("添加要添加的疾病目录的编号\n"
                                                                                 + "每个疾病目录编号不同\n",lineMax)));

        list.add(new IntroductionNotifier(introduction,table,Tool.organize("在表格区域中存放了所有当前设置下检索到的疾病信息\n"
                                                                           + "有名字，ICD编码，助记码,三个部分组成\n"
                                                                                + "可以通过右边的搜索框来改变搜索设置\n",lineMax)));
        list.add(new IntroductionNotifier(introduction,deleteMenuInput,Tool.organize("选择想要删除目录的名字\n"
                                                                                     + "点击下方的删除按钮删除\n",lineMax)));
        list.add(new IntroductionNotifier(introduction,deleteILLInput,Tool.organize("输入想要删除的疾病的名字\n"
                                                                                  +"疾病名不得为空,若不确定疾病名字可以在上方尝试检索\n"
                                                                                        + "输入完成后点击下方的删除以删除疾病\n",lineMax)));
    }

    private void clearAllInput(){
        sreachInput.clear();
        inputILLName.clear();
        inputILLCode.clear();
        inputILLICD.clear();
        inputMenuName.clear();
        inputMenuCode.clear();
        deleteILLInput.clear();
    }

    private void clearAllChoice(){
        sreachMenu.getItems().clear();
        addILLMenuChoice.getItems().clear();
        deleteMenuInput.getItems().clear();
    }

    private void reloadChoicerData(){//在每次数据更新后重新加载UI里的选项数据
        try {

            clearAllChoice();//将所有对话框清空

            MenuManerger manerger = MenuManerger.get();
            Iterator<MenuClass> menuList = manerger.getAllClass();
            sreachMenu.getItems().add(ALL);
            sreachMenu.setValue(ALL);
            addILLMenuChoice.getItems().add(NULL);
            addILLMenuChoice.setValue(NULL);
            deleteMenuInput.getItems().add(NULL);
            deleteMenuInput.setValue(NULL);
            while(
                    menuList.hasNext()
            ){
                MenuClass current = menuList.next();
                sreachMenu.getItems().add(current.getName());
                addILLMenuChoice.getItems().add(current.getName());
                deleteMenuInput.getItems().add(current.getName());
            }
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"尝试数据更新时发生异常");
        }
    }

    private void reloadTableData(){
        //根据选项重新加载列表中的数据,每次数据变动或选项变动时调用
        try{

            ObservableList<IRecord> newData = FXCollections.observableArrayList();
            MenuManerger manerger = MenuManerger.get();
            if(!this.currentILL.equals("全选")){
               IRecord current =  manerger.getILL(currentILL);
               if(current != null)
                   newData.add(current);
            }else if(currentMenu != null && !this.currentMenu.equals("全选")){
                MenuClass current = manerger.getMenu(currentMenu);
                if(current != null){
                    Iterator<IRecord> iter = current.getList();
                    while(iter.hasNext()){
                        newData.add(iter.next());
                    }
                }
            }else{
                Iterator<MenuClass> menu = manerger.getAllClass();
                while(menu.hasNext()){
                    Iterator<IRecord> ill = menu.next().getList();
                    while(ill.hasNext()){
                        newData.add(ill.next());
                    }
                }
            }
            table.setItems(newData);
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"尝试加载列表数据时发生错误");
        }
    }

    private void rowBackToDefualt(){
        currentILL = ALL;
        currentMenu = ALL;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        initIntroduction();
        nameLine.setCellValueFactory(new PropertyValueFactory<>("name"));
        codeLine.setCellValueFactory(new PropertyValueFactory<>("code"));
        ICDLine.setCellValueFactory(new PropertyValueFactory<>("ICD"));
        classLine.setCellValueFactory(new PropertyValueFactory<>("menu"));
        reloadChoicerData();//重置选项
        reloadTableData();//重置列表
    }




    //添加目录
    public void addMenu(){
        try{
            String code = Tool.getNotEmptyInput(inputMenuCode);
            String name = Tool.getNotEmptyInput(inputMenuName);
            MenuManerger.get().add(code,name);
            reloadChoicerData();
            reloadTableData();
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"添加时错误");
        }finally{
            clearAllInput();
        }
    }
    //添加疾病记录
    public void addILLRecord(){
        try{
            String name = Tool.getNotEmptyInput(inputILLName);
            String code = Tool.getNotEmptyInput(inputILLCode);
            String ICD = Tool.getNotEmptyInput(inputILLICD);
            String iclass =  addILLMenuChoice.getValue();
            MenuClass Iclass = MenuManerger.get().getMenu(iclass);
            if(Iclass == null) {
                AlertBox.display("疾病所属目不能为空","创建时异常");
                return;
            }
            Iclass.add(code,name,ICD);
            reloadChoicerData();
            reloadTableData();
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"添加类时错误");
        }finally{
            clearAllInput();
        }
    }

    //返回主场景
    public void onExitPushed(){
        try{
            SceneChanger.get().loadScene("main");
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"转换时错误");
        }
    }

    //当在下拉框查找时
    public void findByChosingMenu(){
        rowBackToDefualt();
        clearAllInput();
        currentMenu = sreachMenu.getValue();
        reloadTableData();
    }

    public void findByInputingName(){
        currentILL = sreachInput.getText();
        reloadTableData();
        //reloadChoicerData();
    }

    public void onDeleteByAdPushed(){
        try{
            String receive = deleteMenuInput.getValue();
            if(receive.equals(NULL)) {
                AlertBox.display("无法删除空的目录", "删除时错误");
            }else {
                if(ConfirmBox.display("是否要删除" + receive+ "目录以及目录下的所有信息","确认"))
                          MenuManerger.get().delete(receive);
            }
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"在删除时出现问题");
        }finally {
            reloadChoicerData();
            reloadTableData();
        }
    }

    public void onDeleteByInputName(){
        try{
            String receive = Tool.getNotEmptyInput(deleteILLInput);
            IRecord ill = MenuManerger.get().getILL(receive);
            if(ill == null){
                AlertBox.display("输入的名字无效","删除时错误");
                return;
            }
            String ClassName = ill.getIclassName();
            if(ConfirmBox.display("确定要删除" + ill.getName() + "吗","删除前确认"))
                 MenuManerger.get().getMenu(ClassName).delete(receive);
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"删除时错误");
        }finally {
            reloadTableData();
        }
    }


}
