package sample;

import sample.Data.BaseData.STime;
import sample.Data.BaseData.ScheduleRule;

import java.util.Iterator;

public class ScheduleTableData {
    private STime time;
    private String doctorList;
    public ScheduleTableData(STime time, Iterator<String> doctorNames){
        this.time = time;
        while(doctorNames.hasNext())
            doctorList += doctorNames.next() + "，";
    }

    public STime getTime() {
        return time;
    }

    public void setTime(STime time) {
        this.time = time;
    }

    public String getDoctorList() {
        return doctorList;
    }

    public void setDoctorList(String doctorList) {
        this.doctorList = doctorList;
    }
}
