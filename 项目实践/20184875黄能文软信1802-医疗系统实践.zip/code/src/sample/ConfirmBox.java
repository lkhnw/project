package sample;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ConfirmBox {
    private static boolean temp;
    public static boolean display(String message,String title) {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle(title);

        VBox box = new VBox(10);
        Label label = new Label(message);
        HBox h = new HBox(10);
        Button Yes = new Button("是");
        Button No = new Button("否");

        window.setOnCloseRequest(e -> e.consume());//禁止窗口点击叉键强行退出

        Yes.setOnAction(e -> {
            temp = true;
            window.close();
        });
        No.setOnAction(e->{
            temp = false;
            window.close();
        });

        h.getChildren().addAll(Yes,No);
        h.setAlignment(Pos.CENTER);
        box.getChildren().addAll(label,h);
        box.setAlignment(Pos.CENTER);
        window.setScene(new Scene(box,300,200));
        window.showAndWait();

        return temp;
    }
}
