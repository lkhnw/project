package sample;

import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import sample.Data.BaseData.*;
import sample.Logic.IntroductionNotifier;
import sample.Logic.Tool;
import sample.TableItems.DoctorNote;
import sample.TableItems.MedicineDeaItem;

import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.ResourceBundle;

public class DoctorUI implements Initializable {

    //等待列表
    public TableView<Case> waitList;
    public TableColumn<Case,String> waitListName;
    private Case currentCase = null;

    private boolean isSelectingClinet;
    private HashMap<Case,PayData> buff = new HashMap<>();


    //患者信息的区域
    public TextField currentName;
    public TextField currentAge;
    public TextField currentNumber;
    private void resetInfor(){
        currentName.clear();
        currentAge.clear();
        currentAge.clear();
    }

    //医生笔记区域
   /* public TableView<DoctorNote> noteList;
    public TableColumn<DoctorNote,String> titleList;
    public TextArea noteContent;
    public TextField titleNameInput;
    private DoctorNote currentNote = null;*/

    /*private void resetNoteArea(){
        noteList.getItems().clear();
        noteContent.clear();
        titleList.setText("");
    }*/

    //医嘱区域
    //public TextArea doctorConclution;


    //处方区域
    public TableView<MedicineDeaItem> medicineList;
    public TableColumn<MedicineDeaItem,String> medicineNameList;
    public TableColumn<MedicineDeaItem,String>  medicineUnitList;
    public TableColumn<MedicineDeaItem,Integer> medicineNumberList;
    public TableColumn<MedicineDeaItem,Float> medicinePriceList;
    public TextField medicineNameInput;
    public TextField medicineNumberInput;
    //public ChoiceBox<String> medicineNameChoice;
    private MedicineDeaItem currentMedicine = null;
    private void resetDeal(){
        medicineList.getItems().clear();
        medicineNameInput.clear();
        medicineNumberInput.clear();
       // medicineNameChoice.getItems().clear();
        currentMedicine = null;
    }

    private final int maxLine = 30;

    //说明
    //public TextArea introduction;


    private void initTable(){
        waitList.getSelectionModel().selectedItemProperty().addListener((e,oldVal,newVal)->{
            if(isSelectingClinet) {
                currentCase = newVal;
                if (currentCase != null) {
                    currentName.setText(currentCase.getName());
                    currentAge.setText("" + currentCase.getAge());
                    currentNumber.setText("" + currentCase.getNumber());
                }
            }
        });
        waitListName.setCellValueFactory(new PropertyValueFactory<>("name"));

        /*noteList.getSelectionModel().selectedItemProperty().addListener((e,oldVal,newVal)->{
            if(newVal != null) {
                if(currentNote == null){
                    currentNote = newVal;
                    return;
                }
                currentNote.setContent(noteContent.getText());
                currentNote = newVal;
                noteContent.setText(currentNote.getContent());
            }
        });
        titleList.setCellValueFactory(new PropertyValueFactory<>("title"));*/

        medicineList.getSelectionModel().selectedItemProperty().addListener((e,oldVal,newVal)->{
            currentMedicine = newVal;
        });
        medicineNumberList.setCellValueFactory(new PropertyValueFactory<>("number"));
        medicineNameList.setCellValueFactory(new PropertyValueFactory<>("name"));
        medicineUnitList.setCellValueFactory(new PropertyValueFactory<>("unit"));
        medicinePriceList.setCellValueFactory(new PropertyValueFactory<>("totalPrice"));
    }

   /* private void initIntroduction(){
        IntroductionNotifier.setNotify(introduction,waitList,"当前所有等待就医的所有患者的名字将会列举在这里\n" +
                "选择其中一条后可以在上方看到这位患者的具体信息" +
                "点击选择为这位患者就诊，点击刷新得到最新信息",maxLine);
        IntroductionNotifier.setNotify(introduction,noteList,"这里可以纪录在就诊时，对患者情况的总结笔记\n" +
                "这里列举了这些笔记的标题。选则一个标题就可以看到条目的具体内容并修改\n" +
                "在下方填好新加的标题的名称后，点击添加就可以新建一个条目，并添加到这个表中" +
                "选择一个标题，点击删除可以删除某一条目",maxLine);
        IntroductionNotifier.setNotify(introduction,doctorConclution,"在者里医生可以书写对患者病情的建议",
                maxLine);
        IntroductionNotifier.setNotify(introduction,medicineList,"在这里医生可以修改对患者药物处方的内容\n" +
                "可以在下面下拉选框或者输入文字修改新加药物的名字，其右边的文字栏填入药物的数量\n" +
                "点击添加将新加入药物，选择一个药物点击删除删除表中的药物",maxLine);
    }*/


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        try{
            initTable();
           // initIntroduction();
            reloadWaitingList();
            isSelectingClinet = true;
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"错误");
        }
    }

    public void reloadWaitingList(){
        try {
            waitList.getItems().clear();
            buff.clear();
            Iterator<PayData> iter = PayDataManerger.get().getData();
            while (iter.hasNext()) {
                PayData data = iter.next();
                if (data.getName().equals("挂号付费") && data.IsPayed()) {
                    Case waitCase = CaseManerger.get().getCase(data.getCaseNumber());
                    waitList.getItems().add(waitCase);
                    buff.put(waitCase,data);
                }
            }
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"读取排队数据时错误");
        }
    }

    public void selectCase(){
        try {
            if (isSelectingClinet) {
                PayDataManerger.get().deleteData(buff.get(currentCase));
                reloadWaitingList();
                isSelectingClinet = false;
                //loadChoiceList();
            } else {
                AlertBox.display("必须看诊完当前患者后才能继续看诊下一个患者", "错误");
            }
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"错误");
        }
    }

   /* public void addTitleToNoteList(){
        if(isSelectingClinet) return;
        try{
            if(!isSelectingClinet) {
                String title = Tool.getNotEmptyInput(titleNameInput);
                for (DoctorNote item : noteList.getItems()) {
                    if (item.getTitle().equals(title)) {
                        AlertBox.display("标题名不得重复", "标题错误");
                        return;
                    }
                }
                DoctorNote newVal = new DoctorNote(title);
                if(currentNote != null) {
                    currentNote.setContent(noteContent.getText());
                    noteContent.clear();
                }
                noteList.getItems().add(newVal);
                currentNote = newVal;
            }
            else AlertBox.display("在没有选定看诊对象时不得使用笔记","错误");
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"添加标题时出错");
        }
    }*/

    /*public void deleteTitle(){
        if(isSelectingClinet) return;
        noteList.getItems().remove(currentNote);
        noteContent.clear();
        currentNote = null;
    }*/

    /*public void loadChoiceList(){
        if(isSelectingClinet) return;
        medicineNameChoice.getItems().clear();
        Iterator<Medicine> iter = MedicineManerger.get().getMedicineList();
        while(iter.hasNext()){
            medicineNameChoice.getItems().add(iter.next().getName());
        }
    }*/

    public void addMedicineChoice(){
        if(isSelectingClinet) return;
        try{
            String name = medicineNameInput.getText();
            /*if(name.length() == 0 || name == null)
                name = medicineNameChoice.getValue();*/
            Medicine m = MedicineManerger.get().findMedicine(name);
            int num = Integer.parseInt(Tool.getNotEmptyInput(medicineNumberInput));
            for(MedicineDeaItem item : medicineList.getItems()){
                if(item.getName().equals(name)) {
                    medicineList.getItems().remove(item);
                    item.setNumber(item.getNumber() + num);
                    medicineList.getItems().add(item);
                    medicineNameInput.clear();
                    //medicineNameChoice.setValue(null);
                    medicineNumberInput.clear();
                    return;
                }
            }
            medicineList.getItems().add(new MedicineDeaItem(m,num));
            medicineNameInput.clear();
            //medicineNameChoice.setValue(null);
            medicineNumberInput.clear();

            return;
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"错误");
        }
    }

    public void deleteMedicine(){
        if(isSelectingClinet) return;
        if(currentMedicine != null){
            if(ConfirmBox.display("是否删除药品" + currentMedicine.getName() + " ? ","确认")){
                medicineList.getItems().remove(currentMedicine);
                currentMedicine = null;
            }
        }
    }

    public void confirmDeal(){
        if(isSelectingClinet) return;
        if(!ConfirmBox.display("是否结束看诊","确认")) return;
        Iterator<MedicineDeaItem> items = medicineList.getItems().iterator();
        while(items.hasNext()){
            MedicineDeaItem item = items.next();
            Case currentCase = null;
            try {
                currentCase = CaseManerger.get().getCase(Integer.parseInt(currentNumber.getText()));
            }catch(Exception e){
                AlertBox.display("无法获得当前病例","错误");
            }
            MedicineTakingManerger.get().addItem(currentCase, item ,
                    PayDataManerger.get().createData(currentCase,item.getName(),item.getTotalPrice()));
        }

        reloadWaitingList();
        resetDeal();
        resetInfor();
       // resetNoteArea();

        isSelectingClinet = true;
    }

    public void exit(){
            try{
                SceneChanger.get().loadScene("main");
            }catch(Exception e){
                AlertBox.display(e.getMessage(),"转场时错误");
            }
        }
}
