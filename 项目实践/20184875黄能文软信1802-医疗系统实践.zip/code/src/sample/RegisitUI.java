package sample;

import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import sample.Data.BaseData.*;
import sample.Logic.IntroductionNotifier;
import sample.Logic.Tool;

import java.net.URL;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Iterator;
import java.util.ResourceBundle;

public class RegisitUI implements Initializable {
    public TextField  caseNumberInput;
    public TextField  nameInput;
    public TextField  IDCodeInput;
    public TextField  homeLocationInput;

    public ComboBox<String> genderInput;
    public ComboBox<Integer> ageInput;
    public ComboBox<String>  wayPaying;
    public ComboBox<String> RegisiterLevel;
    public ComboBox<String> RegisiterAdmisitrive;
    public ComboBox<String> RegisiterDoctor;
    public DatePicker brithDay;

    public CheckBox wetherPrint;
    public TextArea totalCost;
    public Text DoctorText;
    public Text totalText;

    //public TextArea introduction;
    private boolean stopReset = false;

    private int count = 0;
    private int LineMax = 26;
    private HashMap<String,String> nameToID= new HashMap<>();//保存一个医生名字到ID的映射

    boolean[] initList = {false,false};

   /* private void activateDoctorChoice(int index){
        //每次被激活，查看两个是否都有选择，如果都有选择就重置一次医生选择的列表
        initList[index] = true;
        if(initList[0] && initList[1]){
            DoctorText.setVisible(true);
            RegisiterDoctor.setVisible(true);
            totalText.setVisible(true);
            totalCost.setVisible(true);
            reSumPrice();

            initDoctorChoice();
        }
    }*/

    private void reSumPrice() {
        try {
            float price = Constant.getRGprice(
                    Constant.getRegisiterLevel(RegisiterLevel.getValue())) + (wetherPrint.isSelected() ? 1 : 0);
            totalCost.setText(Float.toString(price));
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"在计算价格时出错");
        }
    }


    public void initDoctorChoice(){//初始化医生选择的列表
        try {
            nameToID.clear();
            RegisiterDoctor.getItems().clear();
            HumanSourceManerger manerger = HumanSourceManerger.get();
            Constant.RG_LEVEL level = Constant.getRegisiterLevel(RegisiterLevel.getValue());
            Admisitrative ad = manerger.getAdmisitrative(RegisiterAdmisitrive.getValue());//初始化相关信息


            Iterator<String> users = manerger.getUserList(ad);
            while(users.hasNext()){
                User current = manerger.getUser(users.next());
                if(current instanceof  Doctor){
                    if(Constant.fromDCtoRG(((Doctor) current).getLevel()) == level) {
                        RegisiterDoctor.getItems().add(current.getName());
                        nameToID.put(current.getName(),current.getID());
                    }
                }
            }
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"初始化列表时发生错误");
        }
    }

  /*  private void initIntroduction(){
        IntroductionNotifier.setNotify(introduction,caseNumberInput,
                Tool.organize("在这里输入挂号患者的病例\n" +
                        "如果患者之前信息有记录，那么填完后点击查询按钮自动补全患者信息\n" +
                        "如果患者的信息没有记录，在不全下列信息后，挂号成功就会在系统中留下记录",LineMax));
        IntroductionNotifier.setNotify(introduction,nameInput,Tool.organize("在这里输入患者的名字\n" +
                                                                                       "必填项，患者的名字可以重复，会被记录在系统中",LineMax));
        IntroductionNotifier.setNotify(introduction,IDCodeInput,Tool.organize("输入患者的身份证号码\n" +
                                                                                         "必填，身份证号码会被记在系统中",LineMax));
        IntroductionNotifier.setNotify(introduction,homeLocationInput,Tool.organize("输入患者的家庭住址\n" +
                                                                                               "必填，信息会被记录在系统中",LineMax));
        IntroductionNotifier.setNotify(introduction,genderInput,Tool.organize("选择患者的性别,必填",LineMax));
        IntroductionNotifier.setNotify(introduction,ageInput,Tool.organize("输入患者的年龄\n" +
                                                                                       "患者的年龄不得大于120岁，输入后默认生成生日为患者年龄年前等同时间的日子\n" +
                                                                                            "例如：19岁患者在2019-11-4登记，自动生成的日期就为2000-11-4",LineMax));
        IntroductionNotifier.setNotify(introduction,wayPaying,Tool.organize("输入患者选择支付的方式，必填",LineMax));
        IntroductionNotifier.setNotify(introduction,RegisiterLevel,Tool.organize("输入患者选择的挂号类型\n" +
                                                                                            "每个类型会有不同的价格和不同的医生\n"
                                                                                                +"只有当此项与后面的科室选择结束后患者才可以继续选择治疗医生",LineMax));
        IntroductionNotifier.setNotify(introduction,RegisiterAdmisitrive,Tool.organize("输入患者选择看病的科室\n" +
                                                                                                 "只有当科室选择与挂号类型选择结束后才能开始看病医生的选择",LineMax));
        IntroductionNotifier.setNotify(introduction,RegisiterDoctor,Tool.organize("选择看病医生\n" +
                                                                                             "医生的选择与之前管好类型和科室选择有联系",LineMax));
        IntroductionNotifier.setNotify(introduction,wetherPrint,Tool.organize("选择是否打印纸质的病历（添加一块钱）\n" +
                                                                                           "默认选择是否",LineMax));
        IntroductionNotifier.setNotify(introduction,totalCost,Tool.organize("显示当所有信息填完之后当前挂号的总钱数",LineMax));

        IntroductionNotifier.setNotify(introduction,brithDay,Tool.organize("选择当前病人的出生日期\n" +
                                                                                       "当选择此项后，年龄栏的内容会自动变更为现在输入的数据计算的结果",LineMax));


    }//初始化说明列表*/

    private int fromBrithToAge(LocalDate current){
        LocalDate now = LocalDate.now();
        int distance = now.getYear() - current.getYear();
        if(current.compareTo(now.minusYears(distance)) > 0){
            distance --;
        }
        return distance;
    }//将时间转化成当前患者的年龄

    private LocalDate fromAgeToBrith(int age){//将当前年龄转化成当前出生的时间
        return LocalDate.now().minusYears(age);
    }



    @Override
    public void initialize(URL location, ResourceBundle resources) {
        //initIntroduction();

        genderInput.getItems().addAll("男","女");
      /*  RegisiterDoctor.setVisible(false);
        DoctorText.setVisible(false);
        totalCost.setVisible(false);
        totalText.setVisible(false);*/

        //RegisiterAdmisitrive.setOnAction(e->activateDoctorChoice(0));
        //RegisiterLevel.setOnAction(e->activateDoctorChoice(1));
        wetherPrint.setOnAction(e->reSumPrice());

        for(int i = 0;i != 121;i++){
            ageInput.getItems().add(i);
        }
        wayPaying.getItems().addAll("现金","刷卡","电子支付");

        String[] levelList = Constant.listRegisiterLevel();
        for(int i = 0;i != levelList.length;i++){
            RegisiterLevel.getItems().add(levelList[i]);
        }

        try {
            Iterator<Admisitrative> adList = HumanSourceManerger.get().getAdmisitrativeList();
            while (adList.hasNext()) {
                Admisitrative current = adList.next();
                if(current.isScheduled())
                    RegisiterAdmisitrive.getItems().add(current.getName());
            }
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"初始化科室列表时出现错误");
        }
    }

    //运行中

    public void onSreachButtonPushed(){
        try{
            int number = Integer.parseInt(Tool.getNotEmptyInput(caseNumberInput));
            Case current = CaseManerger.get().getCase(number);
            genderInput.setValue(current.getGender());
            brithDay.setValue(current.getBrith());
            ageInput.setValue(fromBrithToAge(current.getBrith()));
            IDCodeInput.setText(current.getID());
            homeLocationInput.setText(current.getLocation());
            nameInput.setText(current.getName());
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"搜索时错误");
        }
    }//当搜索键被按下时

    public void onDatePickerPiked() {
        int val = fromBrithToAge(brithDay.getValue());
        if (val > 120) {
            ageInput.setValue(120);
            brithDay.setValue(fromAgeToBrith(120));
        } else if (val < 0){
            ageInput.setValue(0);
            brithDay.setValue(fromAgeToBrith(0));
        }else{
            stopReset = true;
            ageInput.setValue(val);
        }
    }

    public void onBrithInput(){
         if(!stopReset)
              brithDay.setValue(fromAgeToBrith(ageInput.getValue()));
         else
             stopReset = false;
    }

    public void onAddButtonPushed(){
        try{

            int caseNum = Integer.parseInt(Tool.getNotEmptyInput(caseNumberInput));
            String name = Tool.getNotEmptyInput(nameInput);
            String IDcode = Tool.getNotEmptyInput(IDCodeInput);
            String location = Tool.getNotEmptyInput(homeLocationInput);
            String gender = Tool.getNotEmptyInput(genderInput);
            LocalDate date = brithDay.getValue();
            Tool.getNotEmptyInput(wayPaying);
            Constant.RG_LEVEL level = Constant.getRegisiterLevel(Tool.getNotEmptyInput(RegisiterLevel));
            String doctorName = Tool.getNotEmptyInput(RegisiterDoctor);
            Doctor doctor = (Doctor)HumanSourceManerger.get().getUser(nameToID.get(doctorName));
            float price = Float.parseFloat(totalCost.getText());


            Case caseData = CaseManerger.get().getCase(caseNum);
            if(caseData == null)
                caseData =  CaseManerger.get().createCase(caseNum,name,gender,date,IDcode,location);
            else if(!caseData.getBrith().equals(date)){
                AlertBox.display("当前用户已存在，日期输入不正确","尝试挂号时错误");
                return;
            }else if(!caseData.getGender().equals(gender)) {
                AlertBox.display("当前用户已存在，性别输不对", "尝试挂号时错误");
                return;
            }
            else if(!caseData.getLocation().equals(location)){
                AlertBox.display("当前用户已经存在，家庭住址输入不对","尝试挂号时错误");
                return;
            }else if(!caseData.getID().equals(IDcode)){
                AlertBox.display("当前用户已经存在，身份证号输入不对","尝试挂号时错误");
                return;
            }else if(!caseData.getName().equals(name)){
                AlertBox.display("当前用户已经存在，姓名输入不对","尝试挂号时错误");
                return;
            }

            RegisiterManerger.get().createRegisiter(caseData,doctor,price);
            AlertBox.display("挂号成功请转到结账界面结账","成功");
            SceneChanger.get().loadScene("main");

        }catch(Exception e) {
            AlertBox.display(e.getMessage(), "尝试挂号时错误");
        }
    }


    public void exit(){
        try{
            SceneChanger.get().loadScene("main");
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"转换时错误");
        }
    }


}
