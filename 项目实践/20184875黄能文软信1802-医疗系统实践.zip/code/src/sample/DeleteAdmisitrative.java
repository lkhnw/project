package sample;

import com.sun.javafx.robot.impl.FXRobotHelper;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import sample.Data.BaseData.Admisitrative;
import sample.Data.BaseData.Constant;
import sample.Data.BaseData.HumanSourceManerger;
import sample.Data.BaseData.User;

import java.net.URL;
import java.util.Iterator;
import java.util.ResourceBundle;

public class DeleteAdmisitrative implements Initializable {

    public ComboBox<String> choice;
    public TextArea instruction;

    private String getInformation(Admisitrative ad)throws Exception{
        String result = "";
        result += "科室名字：" + ad.getName() + "\n";
        result += "科室编码：" + ad.getID() + "\n";
        result += "科室类型：" + Constant.getString(ad.getKind()) + "\n";
        result += "科室职能：" + Constant.getString(ad.getAbility()) + "\n";
        result += "下列为科室所属的用户的信息：\n";

        HumanSourceManerger manerger = HumanSourceManerger.get();
        Iterator<String> user = manerger.getUserList(ad);
        while(user.hasNext()){
            User userData = manerger.getUser(user.next());
            result += "姓名：" + userData.getName() + "ID：" + userData.getID() + "\n";
        }

        return result;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        try {
            HumanSourceManerger manerger = HumanSourceManerger.get();
            Iterator<Admisitrative> iter = manerger.getAdmisitrativeList();
            while(iter.hasNext())
                choice.getItems().add(iter.next().getName());
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"初始化时出现错误");
        }
    }

    public void onNameChoosed(){
        try {
            instruction.clear();
            HumanSourceManerger manerger = HumanSourceManerger.get();
            Admisitrative result = manerger.getAdmisitrative(choice.getValue());
            if(result == null){
                AlertBox.display("不存在科室","获得信息时出错");
            }else{
                instruction.setText(getInformation(result));
            }
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"获得信息时出错");
        }
    }

    public void onDeletePushed(){
        try {
            instruction.clear();
            HumanSourceManerger manerger = HumanSourceManerger.get();
            Admisitrative result = manerger.getAdmisitrative(choice.getValue());
            if(result == null){
                AlertBox.display("不存在科室","删除时出错");
            }else{
                boolean confirm = ConfirmBox.display("确定要删除科室【" + result.getName() +"】吗 ","删除前确认");
                if(confirm) {
                    manerger.deleteAdmisitrative(result.getName());
                    SceneChanger.get().loadScene("main");
                }
            }
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"删除时出错");
        }
    }

    public void onExitPushed(){
        try{
            SceneChanger.get().loadScene("main");
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"转场时");
        }
    }
}
