package sample.TableItems;

import javafx.scene.control.Button;
import sample.TakingMedicineUI;

public class MedicineDealButtonItem {
    private String name;
    private String unit;
    private int num;
    private Button Take;//这里可以写成一个泛型类
    private TakingMedicineUI ui;
    private MedicineDeaItem item;

    public MedicineDealButtonItem(MedicineDeaItem item,TakingMedicineUI ui){
        this.name = item.getName();
        this.num = item.getNumber();
        this.unit = item.getUnit();
        this.Take = new Button("领取");
        this.item = item;
        this.ui = ui;

        this.Take.setOnAction(e->ui.onTakeButtonPushed(this));
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public Button getTake() {
        return Take;
    }

    public void setTake(Button take) {
        Take = take;
    }

    public MedicineDeaItem getItem(){
        return this.item;
    }
}
