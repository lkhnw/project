package sample.TableItems;

import sample.Data.BaseData.Medicine;
import sample.Data.BaseData.MedicineManerger;

public class MedicineDeaItem {
    private String name;
    private String unit;
    private int number;
    private float totalPrice;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
        this.totalPrice = MedicineManerger.get().findMedicine(name).getPrice() * number;
    }

    public float getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(float totalPrice) {
        this.totalPrice = totalPrice;
    }

    public MedicineDeaItem(Medicine medicine,int num){
        this.name = medicine.getName();
        this.unit = medicine.getUnit();
        this.number = num;
        this.totalPrice = num * medicine.getPrice();
    }
}
