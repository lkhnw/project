package sample.TableItems;

import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import sample.Data.BaseData.ScheduleRule;

public class ScheduleRuleTableItem {
    private String name;
    private CheckBox choicen;
    private CheckBox[] boxes;

    public ScheduleRuleTableItem(String name){
        this.name = name;
        this.boxes = new CheckBox[14];
        choicen = new CheckBox();
        choicen.setSelected(true);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public CheckBox[] getBoxes() {
        return boxes;
    }

    public void setBoxes(CheckBox[] boxes) {
        this.boxes = boxes;
    }

    public boolean[][] checkResult(){
        if( ! choicen.isSelected()) return null;
        boolean[][] result = new boolean[7][2];
        for(int i = 0;i != 7;i++){
             for(int j = 0;j != 2;j++){
                 result[i][j] = boxes[i * 2 + j].isSelected();
             }
        }
        return result;
    }


}
