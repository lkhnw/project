package sample.TableItems;

import javafx.scene.control.Button;
import sample.AlertBox;
import sample.ChargingUI;
import sample.ConfirmBox;
import sample.Data.BaseData.Case;
import sample.Data.BaseData.CaseManerger;
import sample.Data.BaseData.PayData;

public class PayingTableItem {
    private String caseName;
    private String name;
    private Button operation;
    private float price;
    private PayData data;
    private ChargingUI ui;

    public PayingTableItem(PayData data,ChargingUI ui)throws Exception{
        caseName = CaseManerger.get().getCase(data.getCaseNumber()).getName();
        name = data.getName();
        operation = new Button("付费");
        price = data.getPrice();

        operation.setOnAction(e->onButtonPushed());

        this.ui = ui;
        this.data = data;
    }

    private void onButtonPushed(){
        if(!ConfirmBox.display("确定对" + name + "的支付，共计" +  price + "元","支付信息提示"))   return;
        //如果点击否的话就取消交易
        data.pay();
        AlertBox.display("支付成功","支付成功！");
        ui.refresh();//刷新窗口
    }


    public String getCaseName() {
        return caseName;
    }

    public void setCaseName(String caseName) {
        this.caseName = caseName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Button getOperation() {
        return operation;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }
}
