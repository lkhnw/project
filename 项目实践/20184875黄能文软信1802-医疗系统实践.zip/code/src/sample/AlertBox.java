package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;


public class AlertBox {
    //出现一个警告窗口
    public static void display(String messege,String title){
        Stage window = new Stage();
        window.setTitle(title);
        window.initModality(Modality.APPLICATION_MODAL);

        VBox box = new VBox(10);
        box.setAlignment(Pos.CENTER);
        Button button = new Button("确定");
        button.setOnAction(e->{
            window.close();
        });

        box.getChildren().addAll(new Label(messege),button);
        window.setOnCloseRequest(e-> e.consume());

        Scene scene = new Scene(box,300,200);
        window.setScene(scene);

        window.show();
    }
}
