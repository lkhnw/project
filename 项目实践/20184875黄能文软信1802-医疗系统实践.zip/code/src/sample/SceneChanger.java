package sample;

import com.sun.javafx.robot.impl.FXRobotHelper;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.util.HashMap;

//管理场景切换的类

public class SceneChanger {


    final int[] SMALL = {500,350};
    final int[] NORMAL = {1080,720};
    final int[] BIG = {1680,1000};


    class SceneGulid{
        public String name;
        public int[] resolution;
        public SceneGulid(String name,int[] resolution){
            this.name = name;
            this.resolution = resolution;
        }
    }


    private HashMap<String,SceneGulid> nameToFile = new HashMap<>();



    private static SceneChanger instance;


    public void settings(){
        //如果有新场景在这里添加

        nameToFile.put("log_in",new SceneGulid("sample.fxml",SMALL));//登陆界面
        nameToFile.put("main",new SceneGulid("SceneDataMain.fxml",NORMAL));//主界面
        nameToFile.put("add_user",new SceneGulid("addUser.fxml",NORMAL));//添加用户的界面
        nameToFile.put("add_ad",new SceneGulid("addAdmisitrative.fxml",NORMAL));//添加科室的界面
        nameToFile.put("delete_user",new SceneGulid("deleteUser.fxml",NORMAL));//删除用户的界面
        nameToFile.put("delete_ad",new SceneGulid("deleteAdmisitrative.fxml",NORMAL));//删除科室的界面
        nameToFile.put("ill_manerge",new SceneGulid("ILLManerger.fxml",NORMAL));//管理疾病数据的界面
        nameToFile.put("schedule",new SceneGulid("ScheduleUI.fxml",NORMAL));//管理排班信息的界面
        nameToFile.put("addregisit",new SceneGulid("RegisitUI.fxml",NORMAL));//挂号界面
        nameToFile.put("charge",new SceneGulid("ChargingUI.fxml",NORMAL));//收费界面
        nameToFile.put("medicine_manerge",new SceneGulid("medicineManerge.fxml",NORMAL));
        nameToFile.put("doctor_deal",new SceneGulid("DoctorUI.fxml",NORMAL));
        nameToFile.put("take_medicine",new SceneGulid("TakingMedicineUI.fxml",NORMAL));

    }



    public static SceneChanger get(){
        if(instance == null)
            instance = new SceneChanger();
        return instance;
    }

    public void loadScene(String sceneName)throws Exception{

        settings();
        SceneGulid setting = nameToFile.get(sceneName);
        if(setting == null)
            throw new  Exception("所要求的场景" + sceneName + "不存在！！！");
        Stage window = FXRobotHelper.getStages().get(0);
        Parent parent = FXMLLoader.load(getClass().getResource(setting.name));
        int[] resolution = setting.resolution;
        window.setScene(new Scene(parent,resolution[0],resolution[1]));
    }
}
