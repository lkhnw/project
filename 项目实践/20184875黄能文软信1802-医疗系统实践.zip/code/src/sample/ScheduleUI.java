package sample;

import javafx.fxml.Initializable;
import javafx.scene.control.*;
import sample.Data.BaseData.ScheduleRule;
import sample.Logic.IntroductionNotifier;
import sample.Logic.Tool;


import java.net.URL;
import java.util.ResourceBundle;

public class ScheduleUI implements Initializable {

    //管理排班的组块
    public TableView<ScheduleTableData> scheduleTable;
    public TableColumn<ScheduleTableData,String>  timeLine;//时间列
    public TableColumn<ScheduleTableData,String>  nameListLine;//名称列表列
    public DatePicker start;//选择排班的开始时间
    public DatePicker end;//选择排班的结束时间

    //管理排班规则的板块
    public TableView<ScheduleRule> ruleTable;
    public TableColumn<ScheduleRule,String> ruleNameLine;//规则名称列
    public TableColumn<ScheduleRule,String> ruleDoctorNameLine;//医生名称列
    public TableColumn<ScheduleRule,String> informLine;//排版信息列

    public ComboBox<String> adChoicer;//选择科室进行筛选


    //对场景中项目进行说明的按钮
    public TextArea introduction;

    //一些常量
    private static int LineMax = 10;
    private static String ALL = "全选";

    public void initIntroduction(){
        IntroductionNotifier.setNotify(introduction,scheduleTable,
                Tool.organize("显示当先排班数据的表格\n" +
                                           "在下面可以选择排班规则和开始和结束时间\n" +
                                                "选择完成后在下面点击添加可以自动跟据规则添加排班",LineMax));
        IntroductionNotifier.setNotify(introduction,start,
                Tool.organize("选择希望生成排班的开始时间\n" +
                                          "开始时间不得为空且不得大于结束时间（可以等于）",LineMax));
        IntroductionNotifier.setNotify(introduction,end,
                                          Tool.organize("选择生成排班的结束时间\n" +
                                                                   "结束时间不得为空且不得小于开始时间（可以等于）",LineMax));
        IntroductionNotifier.setNotify(introduction,ruleTable,
                Tool.organize("在这里管理了当前所有排班规则的信息\n" +
                                              "可以在这里选择一个排班规则以提供给上方进行排班\n" +
                                                    "要添加一个规则点击右方添加按钮进入添加界面\n" +
                                                         "想要删除一个规则选择一个纪录点击右方的删除让它从列表中移除删除\n" +
                                                               "想缩小查看范围可在右边下拉框中选择范围",LineMax));
        IntroductionNotifier.setNotify(introduction,adChoicer,
                Tool.organize("在这里选择查看范围\n" +
                                        "选择科室后，列表中会只有对应科室医生的排班规则",LineMax));

    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        initIntroduction();
        adChoicer.getItems().add(ALL);
        adChoicer.setValue(ALL);
    }

    public void exit(){
        try{
            SceneChanger.get().loadScene("main");
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"转场时错误");
        }
    }

    public void addRule(){

    }

}

