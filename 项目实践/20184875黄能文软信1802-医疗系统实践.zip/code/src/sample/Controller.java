package sample;

import com.sun.javafx.robot.impl.FXRobotHelper;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import sample.Logic.LoginManerger;
import sun.security.util.Password;

public class Controller {

    public TextField userNameInput;
    public PasswordField codeInput;

    public void onLoginPush(){
        try {
            LoginManerger login = LoginManerger.get();
            login.login(userNameInput.getText(),codeInput.getText());
            SceneChanger.get().loadScene("main");
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"登陆时错误");
        }
    }
}
