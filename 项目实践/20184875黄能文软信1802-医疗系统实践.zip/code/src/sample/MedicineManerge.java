package sample;

import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import sample.Data.BaseData.Medicine;
import sample.Data.BaseData.MedicineManerger;
import sample.Logic.IntroductionNotifier;
import sample.Logic.Tool;

import java.net.URL;
import java.util.Iterator;
import java.util.ResourceBundle;

public class MedicineManerge implements Initializable {
    public TableView<Medicine> table;
    public TableColumn<Medicine,String> nameLine;
    public TableColumn<Medicine,String> codeLine;
    public TableColumn<Medicine,Float> priceLine;
    public TableColumn<Medicine,String> unitLine;

    public TextField nameInput;
    public TextField codeInput;
    public TextField unitInput;
    public TextField priceInput;
    public Button addButton;

    public TextField nameSearch;
    public Button searchButton;

    public Button deleteButton;

    public Button reload;

    public TextArea introduction;

    private Medicine selected = null;

    private final int maxLine = 10;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        initColums();
        table.getSelectionModel().selectedItemProperty().addListener((v,oldVal,newVal)-> selected = newVal);
        //选中表中的一项后纪录当前选项
        reloadTable();
        initIntroduction();
    }

    private void initColums(){
        nameLine.setCellValueFactory(new PropertyValueFactory<>("name"));
        codeLine.setCellValueFactory(new PropertyValueFactory<>("code"));
        priceLine.setCellValueFactory(new PropertyValueFactory<>("price"));
        unitLine.setCellValueFactory(new PropertyValueFactory<>("unit"));
    }

    private void reloadTable(){
        table.getItems().clear();
        MedicineManerger manerger = MedicineManerger.get();
        Iterator<Medicine> iter = manerger.getMedicineList();
        while(iter.hasNext()){
            table.getItems().add(iter.next());
        }
    }

    private void initIntroduction(){
       IntroductionNotifier.setNotify(introduction,table,
                "在列表中列出了当前记录在案的所有药品的信息\n" +
                        "列表中分别列出了药品的名称，单个药品的计量单位，药品的编码，药品在该单位下的定价的信息",maxLine);
        IntroductionNotifier.setNotify(introduction,searchButton,
                "可以通过此功能根据药品名查找药品的具体信息\n" +
                        "在右边的输入框内输入了药品名称后，点击查找按钮，如果药品存在，就会在上方显示查找到的药品信息",maxLine);
        IntroductionNotifier.setNotify(introduction,deleteButton,
                "通过此功能可以删除在案的药品\n" +
                        "在上方选择想要删除的药品（用蓝色高亮标出）后，点击删除按钮就可删除该药品",maxLine);
        IntroductionNotifier.setNotify(introduction,reload,
                "点击按钮就可以查看信息更新后的当前所有登记在案的药品信息");
        IntroductionNotifier.setNotify(introduction,addButton,
                "通过此功能可以添加一个新的药品\n" +
                        "在上方输入框中填写药品的名字（不得重复），编号（不得重复），单位，价格后，点击该按钮可以将添加的药品信息添加到记录中 ",maxLine);

    }

    private void clearInput(){
        nameInput.clear();
        codeInput.clear();
        unitInput.clear();
        priceInput.clear();
        nameSearch.clear();
    }







    public void onAddButtonPushed(){
        try {
            String name = Tool.getNotEmptyInput(nameInput);
            String unit = Tool.getNotEmptyInput(unitInput);
            float price = Float.parseFloat(Tool.getNotEmptyInput(priceInput));
            String code = Tool.getNotEmptyInput(codeInput);
            MedicineManerger.get().createMedicine(name,unit,price,code);

            clearInput();
            reloadTable();
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"输入时错误");
        }
    }

    public void onDeleteButtonPushed(){
        try{
            if(!ConfirmBox.display("是否要删除  " + selected.getName() + " ？","注意"))
                return;
            MedicineManerger.get().deleteMedicine(selected.getName());
            clearInput();
            reloadTable();
        }catch(NullPointerException e){
            AlertBox.display("还没有选择删除的药品","删除时错误");
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"删除时错误");
        }
    }

    public void onReloadPuhed(){
        reloadTable();
    }

    public void onSearchPushed(){
        try{
            String name = Tool.getNotEmptyInput(nameSearch);
            Medicine m = MedicineManerger.get().findMedicine(name);
            if(m != null) {
                table.getItems().clear();
                table.getItems().add(m);
            }
            clearInput();
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"查找时错误");
        }
    }

    public void exit(){
        try{
            SceneChanger.get().loadScene("main");
        }catch(Exception e){
            AlertBox.display(e.getMessage(),"转场时错误");
        }
    }


}
